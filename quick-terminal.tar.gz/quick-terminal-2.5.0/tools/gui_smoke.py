#!/usr/bin/env python3
"""Exercise GTK4/VTE tab double-click creation and signal-safe closing."""

from __future__ import annotations

import warnings

import gi
from gi import PyGIWarning

warnings.simplefilter("error", PyGIWarning)

from quick_terminal.application import QuickTerminalApplication  # noqa: E402
from quick_terminal.gtk_runtime import GLib  # noqa: E402
from quick_terminal.paths import DEFAULT_SHELL, preferred_shell  # noqa: E402


class TabInteractionProbeApplication(QuickTerminalApplication):
    """Emit a tab-title double-click, close the new tab, and exit."""

    def __init__(self) -> None:
        super().__init__(initial_theme="lwm-blue")
        self._probe_started = False
        self._expected_directory = ""

    def do_activate(self) -> None:
        super().do_activate()
        if self._probe_started:
            return
        self._probe_started = True

        window = self._current_window()
        if window is None:
            raise RuntimeError("Quick Terminal did not create a window")
        if preferred_shell() != DEFAULT_SHELL:
            raise RuntimeError(f"expected {DEFAULT_SHELL} as the default shell")

        session = window.current_session()
        if session is None or session.tab_click_gesture is None:
            raise RuntimeError("the initial tab has no double-click gesture")
        self._expected_directory = session.working_directory
        session.tab_click_gesture.emit("pressed", 2, 0.0, 0.0)

        def verify_open_and_close() -> bool:
            if len(window._sessions) != 2:
                raise RuntimeError("the tab double-click did not create one new tab")
            current = window.current_session()
            if current is None:
                raise RuntimeError("the new terminal tab is not selected")
            if current.working_directory != self._expected_directory:
                raise RuntimeError("the new tab did not inherit the source directory")
            window._queue_session_removal(current)
            return GLib.SOURCE_REMOVE

        def verify_close_and_finish() -> bool:
            if len(window._sessions) != 1:
                raise RuntimeError("the queued terminal tab was not removed")
            self.quit()
            return GLib.SOURCE_REMOVE

        GLib.timeout_add(300, verify_open_and_close)
        GLib.timeout_add(1_100, verify_close_and_finish)


def main() -> int:
    status = int(TabInteractionProbeApplication().run(["terminal-gui-smoke"]))
    if status == 0:
        print("GTK4/VTE tab interaction smoke test passed")
    return status


if __name__ == "__main__":
    raise SystemExit(main())
