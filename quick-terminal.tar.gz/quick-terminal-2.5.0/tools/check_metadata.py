#!/usr/bin/env python3
"""Validate project metadata with standard-library parsers."""

from __future__ import annotations

import configparser
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    desktop_path = ROOT / "data/net.techtimejourney.QuickTerminal.desktop"
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    parser.optionxform = str
    parser.read(desktop_path, encoding="utf-8")
    entry = parser["Desktop Entry"]
    assert entry["Type"] == "Application"
    assert entry["Exec"] == "terminal"
    assert entry["TryExec"] == "terminal"
    assert entry["Icon"] == "net.techtimejourney.QuickTerminal"

    metainfo = ROOT / "data/net.techtimejourney.QuickTerminal.metainfo.xml"
    tree = ET.parse(metainfo)
    root = tree.getroot()
    assert root.findtext("id") == "net.techtimejourney.QuickTerminal"
    assert root.findtext("provides/binary") == "terminal"

    icon = (
        ROOT / "data/icons/hicolor/scalable/apps/net.techtimejourney.QuickTerminal.svg"
    )
    assert ET.parse(icon).getroot().tag.endswith("svg")
    print("Metadata OK: desktop entry, AppStream XML, and SVG icon")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
