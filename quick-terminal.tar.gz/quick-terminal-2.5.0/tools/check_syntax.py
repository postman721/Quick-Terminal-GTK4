#!/usr/bin/env python3
"""Parse project Python files without creating bytecode caches."""

from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {".git", ".venv", "build", "dist", "debian/tmp", "debian/quick-terminal"}


def excluded(path: Path) -> bool:
    relative = path.relative_to(ROOT).as_posix()
    return any(relative == item or relative.startswith(f"{item}/") for item in EXCLUDED)


def main() -> int:
    files = sorted(path for path in ROOT.rglob("*.py") if not excluded(path))
    for path in files:
        source = path.read_text(encoding="utf-8")
        ast.parse(source, filename=str(path))
    print(f"Syntax OK: {len(files)} Python files checked")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
