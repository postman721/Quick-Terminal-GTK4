#!/usr/bin/env python3
"""Remove or reject Python bytecode in source trees and release archives.

Quick Terminal intentionally ships and runs as source-only Python. The guard is
standard-library-only, so it can run before GTK, packaging, or test dependencies
are installed.
"""

from __future__ import annotations

import argparse
import io
import shutil
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path
from typing import Iterable

BYTECODE_SUFFIXES = {".pyc", ".pyo"}
CACHE_DIRECTORY = "__pycache__"
ARCHIVE_SUFFIXES = (
    ".zip",
    ".whl",
    ".tar",
    ".tar.gz",
    ".tgz",
    ".tar.xz",
    ".txz",
    ".tar.bz2",
    ".tbz2",
)


def is_bytecode_name(name: str) -> bool:
    """Return whether an archive or filesystem name is Python bytecode."""

    normalized = name.replace("\\", "/").strip("/")
    parts = tuple(part for part in normalized.split("/") if part)
    return (
        CACHE_DIRECTORY in parts or Path(normalized).suffix.lower() in BYTECODE_SUFFIXES
    )


def tree_bytecode(root: Path) -> list[Path]:
    """List bytecode files and cache directories below ``root``."""

    if root.is_file():
        return [root] if is_bytecode_name(root.name) else []
    if not root.exists():
        return []
    return sorted(
        path
        for path in root.rglob("*")
        if path.name == CACHE_DIRECTORY or path.suffix.lower() in BYTECODE_SUFFIXES
    )


def clean_tree(root: Path) -> int:
    """Delete bytecode safely and return the number of removed entries."""

    entries = tree_bytecode(root)
    # Remove files first and directories deepest-first to avoid duplicate work.
    files = [path for path in entries if path.is_file() or path.is_symlink()]
    directories = sorted(
        (path for path in entries if path.is_dir()),
        key=lambda path: len(path.parts),
        reverse=True,
    )
    for path in files:
        path.unlink(missing_ok=True)
    for path in directories:
        shutil.rmtree(path, ignore_errors=True)
    return len(files) + len(directories)


def _zip_bytecode(archive: Path) -> list[str]:
    with zipfile.ZipFile(archive) as handle:
        return sorted(
            info.filename
            for info in handle.infolist()
            if is_bytecode_name(info.filename)
        )


def _tar_bytecode(archive: Path) -> list[str]:
    with tarfile.open(archive, mode="r:*") as handle:
        return sorted(
            member.name
            for member in handle.getmembers()
            if is_bytecode_name(member.name)
        )


def _deb_bytecode(archive: Path) -> list[str]:
    """Inspect the filesystem tar stream exposed by dpkg-deb."""

    if shutil.which("dpkg-deb") is None:
        raise RuntimeError("dpkg-deb is required to inspect Debian packages")
    completed = subprocess.run(
        ["dpkg-deb", "--fsys-tarfile", str(archive)],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    with tarfile.open(fileobj=io.BytesIO(completed.stdout), mode="r:*") as handle:
        return sorted(
            member.name
            for member in handle.getmembers()
            if is_bytecode_name(member.name)
        )


def archive_bytecode(archive: Path) -> list[str]:
    """List bytecode entries in a supported release archive."""

    lower = archive.name.lower()
    if lower.endswith((".zip", ".whl")):
        return _zip_bytecode(archive)
    if lower.endswith(".deb"):
        return _deb_bytecode(archive)
    if lower.endswith(ARCHIVE_SUFFIXES):
        return _tar_bytecode(archive)
    raise ValueError(f"unsupported archive type: {archive}")


def iter_failures(paths: Iterable[Path]) -> Iterable[str]:
    """Yield readable failures for directories, files, and archives."""

    for path in paths:
        if not path.exists():
            yield f"missing path: {path}"
            continue
        if path.is_dir():
            for entry in tree_bytecode(path):
                yield str(entry)
            continue
        try:
            entries = archive_bytecode(path)
        except ValueError:
            entries = [path.name] if is_bytecode_name(path.name) else []
        except (
            OSError,
            subprocess.CalledProcessError,
            tarfile.TarError,
            zipfile.BadZipFile,
        ) as error:
            yield f"could not inspect {path}: {error}"
            continue
        for entry in entries:
            yield f"{path}: {entry}"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Remove or reject Python bytecode in Quick Terminal artifacts."
    )
    parser.add_argument(
        "paths",
        nargs="*",
        type=Path,
        default=[Path.cwd()],
        help="source directories or archives to inspect",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="remove bytecode from directory arguments before checking",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    options = build_parser().parse_args(argv)
    paths: list[Path] = options.paths
    removed = 0
    if options.clean:
        for path in paths:
            if path.is_dir():
                removed += clean_tree(path)

    failures = list(iter_failures(paths))
    if failures:
        print("Python bytecode detected:", file=sys.stderr)
        for failure in failures:
            print(f"  {failure}", file=sys.stderr)
        return 1

    suffix = (
        f"; removed {removed} cache entr{'y' if removed == 1 else 'ies'}"
        if options.clean
        else ""
    )
    print(f"Bytecode-free: {len(paths)} path(s) checked{suffix}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
