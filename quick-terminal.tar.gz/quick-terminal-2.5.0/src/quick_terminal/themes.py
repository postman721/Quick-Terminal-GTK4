"""Small immutable-by-convention theme definitions shared by the application."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations


class ThemeDefinition:
    """GTK stylesheet and VTE colours for one bundled LWM theme.

    A hand-written slotted class keeps the always-loaded CLI path smaller than a
    dataclass-based model. Theme instances are module constants and are never
    mutated after construction.
    """

    __slots__ = (
        "key",
        "display_name",
        "css_filename",
        "background",
        "foreground",
        "cursor",
        "cursor_foreground",
        "selection_background",
        "selection_foreground",
        "palette",
    )

    def __init__(
        self,
        *,
        key: str,
        display_name: str,
        css_filename: str,
        background: str,
        foreground: str,
        cursor: str,
        cursor_foreground: str,
        selection_background: str,
        selection_foreground: str,
        palette: tuple[str, ...],
    ) -> None:
        if len(palette) != 16:
            raise ValueError(f"{display_name} must define exactly 16 ANSI colours")
        self.key = key
        self.display_name = display_name
        self.css_filename = css_filename
        self.background = background
        self.foreground = foreground
        self.cursor = cursor
        self.cursor_foreground = cursor_foreground
        self.selection_background = selection_background
        self.selection_foreground = selection_foreground
        self.palette = palette

    def load_css(self) -> str:
        """Load the selected stylesheet and retain only the newest theme."""

        global _CSS_CACHE_KEY, _CSS_CACHE_VALUE
        if _CSS_CACHE_KEY == self.key and _CSS_CACHE_VALUE is not None:
            return _CSS_CACHE_VALUE

        # Importing resources is deferred so ``terminal --help`` and
        # ``terminal --version`` keep a minimal dependency footprint.
        from importlib import resources

        css = (
            resources.files("quick_terminal.resources.themes")
            .joinpath(self.css_filename)
            .read_text(encoding="utf-8")
        )
        _CSS_CACHE_KEY = self.key
        _CSS_CACHE_VALUE = css
        return css


_CSS_CACHE_KEY: str | None = None
_CSS_CACHE_VALUE: str | None = None


def clear_css_cache() -> None:
    """Release the one retained stylesheet during application shutdown."""

    global _CSS_CACHE_KEY, _CSS_CACHE_VALUE
    _CSS_CACHE_KEY = None
    _CSS_CACHE_VALUE = None


# ANSI palettes retain readable contrast while matching the surrounding GTK UI.
LWM_GRAPHITE = ThemeDefinition(
    key="lwm-graphite",
    display_name="LWM Graphite",
    css_filename="lwm_graphite.css",
    background="#17191b",
    foreground="#eef1f2",
    cursor="#c3d1d6",
    cursor_foreground="#17191b",
    selection_background="#4a5b63",
    selection_foreground="#ffffff",
    palette=(
        "#17191b",
        "#d98282",
        "#8fbf9f",
        "#d8b56a",
        "#7fa6c9",
        "#b59acb",
        "#86b9be",
        "#d8dcde",
        "#667077",
        "#ef9a9a",
        "#a6d5b2",
        "#ebca86",
        "#96bad8",
        "#c9aedb",
        "#9bcbd0",
        "#ffffff",
    ),
)

LWM_DARK = ThemeDefinition(
    key="lwm-dark",
    display_name="LWM Dark",
    css_filename="lwm_dark.css",
    background="#000000",
    foreground="#ffffff",
    cursor="#00a8ff",
    cursor_foreground="#000000",
    selection_background="#003d5f",
    selection_foreground="#ffffff",
    palette=(
        "#000000",
        "#e06c75",
        "#98c379",
        "#e5c07b",
        "#61afef",
        "#c678dd",
        "#56b6c2",
        "#d7dae0",
        "#666666",
        "#ff7b86",
        "#b3dc8c",
        "#f3d28b",
        "#78bfff",
        "#d792ed",
        "#6ccbd7",
        "#ffffff",
    ),
)

LWM_BLUE = ThemeDefinition(
    key="lwm-blue",
    display_name="LWM Blue",
    css_filename="lwm_blue.css",
    background="#06172d",
    foreground="#ffffff",
    cursor="#ffffff",
    cursor_foreground="#0a2b52",
    selection_background="#1769aa",
    selection_foreground="#ffffff",
    palette=(
        "#06172d",
        "#ff7f8a",
        "#84e1a8",
        "#ffd479",
        "#70c7ff",
        "#d8a4ff",
        "#73e6e6",
        "#ffffff",
        "#41698f",
        "#ff9ca5",
        "#a2f0bd",
        "#ffe39c",
        "#9ad9ff",
        "#e6c1ff",
        "#9af2f2",
        "#ffffff",
    ),
)

THEMES = {
    LWM_GRAPHITE.key: LWM_GRAPHITE,
    LWM_DARK.key: LWM_DARK,
    LWM_BLUE.key: LWM_BLUE,
}
DEFAULT_THEME = LWM_GRAPHITE.key
_THEME_ALIASES = {
    "graphite": LWM_GRAPHITE.key,
    "lwm graphite": LWM_GRAPHITE.key,
    "dark": LWM_DARK.key,
    "lwm dark": LWM_DARK.key,
    "blue": LWM_BLUE.key,
    "lwm blue": LWM_BLUE.key,
}


def normalize_theme(value: str | None) -> str:
    """Return a registered key while accepting concise user-facing aliases."""

    normalized = (value or "").strip().lower().replace("_", "-")
    normalized = _THEME_ALIASES.get(normalized, normalized)
    return normalized if normalized in THEMES else DEFAULT_THEME
