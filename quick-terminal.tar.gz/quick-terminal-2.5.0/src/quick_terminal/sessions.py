"""Terminal-session ownership, compact lookup, and signal-safe cleanup."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from collections.abc import Iterator

from .gtk_runtime import Gio, GLib, Gtk, Vte

_CLEANUP_ERRORS = (AttributeError, GLib.Error, RuntimeError, TypeError, ValueError)
_REGISTRY_COMPACT_AT = 32


def cancel_source(source_id: int) -> None:
    """Remove one pending GLib source when it still exists."""

    if not source_id:
        return
    try:
        GLib.source_remove(source_id)
    except _CLEANUP_ERRORS:
        pass


def cancel_operation(cancellable: Gio.Cancellable | None) -> None:
    """Cancel one asynchronous operation without interrupting teardown."""

    if cancellable is None:
        return
    try:
        cancellable.cancel()
    except _CLEANUP_ERRORS:
        pass


def _disconnect(instance: object, handler_id: int) -> None:
    """Disconnect one application-owned GObject signal when possible."""

    if not handler_id:
        return
    try:
        instance.disconnect(handler_id)  # type: ignore[attr-defined]
    except _CLEANUP_ERRORS:
        pass


class TerminalSession:
    """Resources owned by one terminal tab.

    The class is intentionally hand-written and slotted. It avoids dataclass
    runtime overhead and makes every retained reference explicit. ``dispose``
    cancels Python-owned work, disconnects callbacks, and drops Python wrapper
    references. It never resets live VTE state or manually unparents widgets;
    GTK removes the notebook page from an idle callback and releases the native
    hierarchy in its normal ownership order.
    """

    __slots__ = (
        "token",
        "page",
        "terminal",
        "tab_label",
        "close_button",
        "tab_click_gesture",
        "working_directory",
        "spawn_cancellable",
        "close_prompt_cancellable",
        "child_exited_handler_id",
        "title_changed_handler_id",
        "close_handler_id",
        "tab_click_handler_id",
        "focus_source_id",
        "removal_source_id",
        "closing",
        "disposed",
    )

    def __init__(
        self,
        *,
        token: int,
        page: Gtk.ScrolledWindow,
        terminal: Vte.Terminal,
        tab_label: Gtk.Label,
        close_button: Gtk.Button,
        working_directory: str,
        tab_click_gesture: Gtk.GestureClick | None = None,
        spawn_cancellable: Gio.Cancellable | None = None,
        close_prompt_cancellable: Gio.Cancellable | None = None,
        child_exited_handler_id: int = 0,
        title_changed_handler_id: int = 0,
        close_handler_id: int = 0,
        tab_click_handler_id: int = 0,
        focus_source_id: int = 0,
        removal_source_id: int = 0,
        closing: bool = False,
        disposed: bool = False,
    ) -> None:
        self.token = token
        self.page = page
        self.terminal = terminal
        self.tab_label = tab_label
        self.close_button = close_button
        self.tab_click_gesture = tab_click_gesture
        self.working_directory = working_directory
        self.spawn_cancellable = spawn_cancellable
        self.close_prompt_cancellable = close_prompt_cancellable
        self.child_exited_handler_id = child_exited_handler_id
        self.title_changed_handler_id = title_changed_handler_id
        self.close_handler_id = close_handler_id
        self.tab_click_handler_id = tab_click_handler_id
        self.focus_source_id = focus_source_id
        self.removal_source_id = removal_source_id
        self.closing = closing
        self.disposed = disposed

    def finish_spawn(self) -> None:
        """Release the one-shot cancellable after shell startup completes."""

        self.spawn_cancellable = None

    def dispose(self) -> None:
        """Cancel callbacks and break application-owned references once."""

        if self.disposed:
            return
        self.disposed = True
        self.closing = True

        spawn_operation = self.spawn_cancellable
        prompt_operation = self.close_prompt_cancellable
        self.spawn_cancellable = None
        self.close_prompt_cancellable = None
        cancel_operation(spawn_operation)
        cancel_operation(prompt_operation)

        cancel_source(self.focus_source_id)
        cancel_source(self.removal_source_id)
        self.focus_source_id = 0
        self.removal_source_id = 0

        # Keep local references only for the disconnect calls. Clearing the
        # session fields afterwards ensures an accidentally retained session
        # cannot keep the complete GTK/VTE tab hierarchy alive.
        terminal = self.terminal
        close_button = self.close_button
        tab_click_gesture = self.tab_click_gesture
        _disconnect(terminal, self.child_exited_handler_id)
        _disconnect(terminal, self.title_changed_handler_id)
        _disconnect(close_button, self.close_handler_id)
        _disconnect(tab_click_gesture, self.tab_click_handler_id)
        self.child_exited_handler_id = 0
        self.title_changed_handler_id = 0
        self.close_handler_id = 0
        self.tab_click_handler_id = 0

        self.page = None
        self.terminal = None
        self.tab_label = None
        self.close_button = None
        self.tab_click_gesture = None
        self.working_directory = ""


class SessionRegistry:
    """Own sessions with one strong reference and one page-token index.

    Terminal signal handlers receive the integer token as callback data, so the
    registry no longer needs a second entry for every VTE widget. Sparse tables
    are rebuilt only after a large tab burst has shrunk to one quarter of its
    peak size.
    """

    __slots__ = ("_items", "_page_tokens", "_peak_size")

    def __init__(self) -> None:
        self._items: dict[int, TerminalSession] = {}
        self._page_tokens: dict[int, int] = {}
        self._peak_size = 0

    def __iter__(self) -> Iterator[TerminalSession]:
        return iter(self._items.values())

    def __len__(self) -> int:
        return len(self._items)

    def __bool__(self) -> bool:
        return bool(self._items)

    def __contains__(self, session: object) -> bool:
        return (
            isinstance(session, TerminalSession)
            and self._items.get(session.token) is session
        )

    def add(self, session: TerminalSession) -> None:
        """Register a new session and reject accidental token reuse."""

        existing = self._items.get(session.token)
        if existing is session:
            return
        if existing is not None:
            raise ValueError(f"duplicate terminal session token: {session.token}")
        self._items[session.token] = session
        self._page_tokens[id(session.page)] = session.token
        self._peak_size = max(self._peak_size, len(self._items))

    def remove(self, session: TerminalSession) -> bool:
        """Remove one session from the owner and page lookup tables."""

        if self._items.get(session.token) is not session:
            return False
        del self._items[session.token]
        self._page_tokens.pop(id(session.page), None)
        self._compact_if_sparse()
        return True

    def _compact_if_sparse(self) -> None:
        active = len(self._items)
        if active == 0:
            self._items.clear()
            self._page_tokens.clear()
            self._peak_size = 0
            return
        if self._peak_size < _REGISTRY_COMPACT_AT or active * 4 > self._peak_size:
            return
        self._items = dict(self._items)
        self._page_tokens = dict(self._page_tokens)
        self._peak_size = active

    def pop(self) -> TerminalSession | None:
        """Remove and return one session without allocating a bulk copy."""

        if not self._items:
            return None
        _token, session = self._items.popitem()
        self._page_tokens.pop(id(session.page), None)
        if not self._items:
            # ``popitem`` can leave a large empty table after tab churn. Clearing
            # both dictionaries returns that capacity before the window dies.
            self._items.clear()
            self._page_tokens.clear()
            self._peak_size = 0
        return session

    def for_token(self, token: int) -> TerminalSession | None:
        return self._items.get(token)

    def for_page(self, page: Gtk.Widget | None) -> TerminalSession | None:
        if page is None:
            return None
        token = self._page_tokens.get(id(page))
        return None if token is None else self._items.get(token)
