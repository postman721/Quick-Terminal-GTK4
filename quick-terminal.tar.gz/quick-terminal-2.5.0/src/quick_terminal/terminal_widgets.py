"""Construct VTE widgets and provide small terminal-specific helpers."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from collections.abc import Callable, Iterable

from .gtk_runtime import Gdk, Gio, GLib, Gtk, Pango, Vte
from .paths import preferred_shell, shell_quoted_drop_payload
from .sessions import TerminalSession
from .theme_runtime import apply_terminal_theme
from .themes import ThemeDefinition

SignalHandler = Callable[..., object]
SCROLLBACK_LINES = 1_024
SPAWN_TIMEOUT_MS = -1
_TERMINAL_FONT: Pango.FontDescription | None = None


def _terminal_font() -> Pango.FontDescription:
    """Return one shared font description for every terminal tab."""

    global _TERMINAL_FONT
    if _TERMINAL_FONT is None:
        _TERMINAL_FONT = Pango.FontDescription("Monospace 11")
    return _TERMINAL_FONT


def clear_terminal_widget_caches() -> None:
    """Release the shared font wrapper during application shutdown."""

    global _TERMINAL_FONT
    _TERMINAL_FONT = None


def create_terminal(
    *,
    context_menu: Gio.Menu,
    theme: ThemeDefinition,
) -> Vte.Terminal:
    """Create one bounded and consistently configured VTE terminal."""

    terminal = Vte.Terminal()
    terminal.add_css_class("terminal-surface")
    terminal.set_hexpand(True)
    terminal.set_vexpand(True)
    terminal.set_scrollback_lines(SCROLLBACK_LINES)
    terminal.set_scroll_on_output(False)
    terminal.set_scroll_on_keystroke(True)
    terminal.set_mouse_autohide(True)
    # Quick Terminal does not expose hyperlink or SIXEL features. Disabling
    # both keeps their metadata and decoded image surfaces out of scrollback.
    terminal.set_allow_hyperlink(False)
    terminal.set_enable_sixel(False)
    terminal.set_audible_bell(False)
    terminal.set_font(_terminal_font())
    terminal.set_cursor_blink_mode(Vte.CursorBlinkMode.SYSTEM)
    terminal.set_cursor_shape(Vte.CursorShape.BLOCK)
    terminal.set_context_menu_model(context_menu)
    install_file_drop_target(terminal)
    apply_terminal_theme(terminal, theme)
    return terminal


def create_terminal_page(terminal: Vte.Terminal) -> Gtk.ScrolledWindow:
    """Wrap a terminal in the notebook's scrolling page."""

    page = Gtk.ScrolledWindow()
    page.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    page.set_hexpand(True)
    page.set_vexpand(True)
    page.set_child(terminal)
    return page


def create_tab_header() -> tuple[Gtk.Box, Gtk.Label, Gtk.Button]:
    """Create a compact tab title and close button."""

    tab_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
    tab_box.add_css_class("terminal-tab-label")

    title_label = Gtk.Label(label="Terminal")
    title_label.set_ellipsize(Pango.EllipsizeMode.END)
    title_label.set_max_width_chars(26)
    title_label.set_tooltip_text("Double-click this tab to open a new one")
    tab_box.append(title_label)

    close_button = Gtk.Button.new_from_icon_name("window-close-symbolic")
    close_button.set_tooltip_text("Close tab (Ctrl+Shift+W)")
    close_button.set_focus_on_click(False)
    close_button.add_css_class("flat")
    close_button.add_css_class("tab-close-button")
    tab_box.append(close_button)
    return tab_box, title_label, close_button


def install_file_drop_target(terminal: Vte.Terminal) -> None:
    """Attach a terminal-owned file-list drop controller.

    The callback is a module function rather than a window closure, so the drop
    target cannot retain a session or application object.
    """

    target = Gtk.DropTarget.new(Gdk.FileList.__gtype__, Gdk.DragAction.COPY)
    target.connect("drop", _on_file_drop)
    terminal.add_controller(target)


def _drop_candidates(file_list: Gdk.FileList) -> Iterable[str]:
    """Yield local paths or URIs without building another file-object list."""

    for file_object in file_list.get_files():
        candidate = file_object.get_path() or file_object.get_uri()
        if candidate:
            yield candidate


def _on_file_drop(
    target: Gtk.DropTarget,
    file_list: Gdk.FileList,
    _x: float,
    _y: float,
) -> bool:
    terminal = target.get_widget()
    if terminal is None:
        return False

    payload = shell_quoted_drop_payload(_drop_candidates(file_list))
    if not payload:
        return False
    terminal.feed_child(payload)
    terminal.grab_focus()
    return True


def spawn_shell(session: TerminalSession, callback: SignalHandler) -> None:
    """Start Bash asynchronously with cancellable, compact callback data."""

    if session.disposed or not session.working_directory:
        raise RuntimeError("cannot spawn a disposed terminal session")

    cancellable = Gio.Cancellable()
    session.spawn_cancellable = cancellable
    try:
        session.terminal.spawn_async(
            Vte.PtyFlags.DEFAULT,
            session.working_directory,
            [preferred_shell()],
            None,  # inherit the parent environment
            GLib.SpawnFlags.DEFAULT,
            None,  # child_setup
            None,  # child_setup_data required by the PyGObject binding
            SPAWN_TIMEOUT_MS,
            cancellable,
            callback,
            session.token,
        )
    except Exception:
        session.spawn_cancellable = None
        cancellable.cancel()
        raise


def current_terminal_directory(terminal: Vte.Terminal) -> str | None:
    """Return the local path represented by VTE's current-directory URI."""

    try:
        uri = terminal.get_current_directory_uri()
        return Gio.File.new_for_uri(uri).get_path() if uri else None
    except (GLib.Error, RuntimeError, TypeError, ValueError):
        return None


def copy_selection(terminal: Vte.Terminal) -> None:
    """Copy selected plain text and restore terminal focus."""

    terminal.copy_clipboard_format(Vte.Format.TEXT)
    terminal.grab_focus()
