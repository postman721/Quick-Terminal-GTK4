"""Bounded shell, path, display-text, and file-drop helpers."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import os
import shlex
from collections.abc import Iterable, Mapping

DEFAULT_SHELL = "/bin/bash"
MAX_DROP_ITEMS = 128
MAX_DROP_BYTES = 32 * 1024
MAX_DROP_ITEM_CHARS = 8 * 1024
_DISPLAY_TRANSLATION = str.maketrans({"\r": " ", "\n": " ", "\t": " "})
_CACHED_SHELL: str | None = None


def _first_executable(candidates: Iterable[str | None]) -> str:
    """Return the first executable regular file, falling back to ``/bin/sh``."""

    for candidate in candidates:
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return "/bin/sh"


def _process_shell() -> str:
    """Resolve the process shell once, preferring Bash for every terminal tab."""

    global _CACHED_SHELL
    if _CACHED_SHELL is None:
        _CACHED_SHELL = _first_executable(
            (DEFAULT_SHELL, os.environ.get("SHELL"), "/bin/sh")
        )
    return _CACHED_SHELL


def clear_path_caches() -> None:
    """Release the single cached shell path during application shutdown."""

    global _CACHED_SHELL
    _CACHED_SHELL = None


def preferred_shell(environment: Mapping[str, str] | None = None) -> str:
    """Return Bash when available, with safe fallbacks for unusual systems."""

    if environment is None:
        return _process_shell()
    return _first_executable((DEFAULT_SHELL, environment.get("SHELL"), "/bin/sh"))


def safe_working_directory(
    value: str | None,
    environment: Mapping[str, str] | None = None,
) -> str:
    """Return the first usable directory while preserving symlink components."""

    values = os.environ if environment is None else environment
    try:
        current_directory = os.getcwd()
    except OSError:
        current_directory = "/"

    # There are only four candidates; a short list is smaller than a set and
    # keeps duplicate suppression obvious.
    visited: list[str] = []
    for candidate in (value, values.get("HOME"), current_directory, "/"):
        if not candidate:
            continue
        try:
            path = os.path.abspath(os.path.expanduser(candidate))
        except (OSError, TypeError, ValueError):
            continue
        if path in visited:
            continue
        visited.append(path)
        if os.path.isdir(path):
            return path
    return "/"


def bounded_display_text(value: str | None, fallback: str, limit: int) -> str:
    """Sanitize and bound terminal-controlled titles or displayed paths."""

    if limit < 2:
        raise ValueError("display-text limit must be at least 2")
    # Bound input before normalization so an oversized OSC title cannot force
    # large temporary allocations. ``translate`` performs all replacements in
    # one pass instead of allocating one string per ``replace`` call.
    text = (value or "")[: limit * 4].translate(_DISPLAY_TRANSLATION).strip()
    if not text:
        return fallback
    return text if len(text) <= limit else f"{text[: limit - 1]}…"


def shell_quoted_drop_payload(candidates: Iterable[str]) -> bytes:
    """Return bounded shell-quoted input for one GTK file drop.

    The limits cap both transient Python memory and the amount of text sent to
    the child PTY. The trailing space lets the user review or extend the command
    before pressing Enter.
    """

    payload = bytearray()
    accepted = 0
    for candidate in candidates:
        if accepted >= MAX_DROP_ITEMS:
            break
        if not candidate or len(candidate) > MAX_DROP_ITEM_CHARS:
            continue
        quoted = shlex.quote(candidate).encode("utf-8", errors="surrogateescape")
        separator = 1 if payload else 0
        if len(payload) + separator + len(quoted) + 1 > MAX_DROP_BYTES:
            break
        if separator:
            payload.append(0x20)
        payload.extend(quoted)
        accepted += 1

    if payload:
        payload.append(0x20)
    return bytes(payload)
