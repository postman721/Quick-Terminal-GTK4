"""Dependency-light command-line parsing and lazy GTK handoff."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import argparse
import os
import sys
from collections.abc import Sequence

from . import APP_NAME, COMMAND_NAME, VERSION
from .themes import THEMES


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=COMMAND_NAME,
        description="A lightweight GTK4/VTE terminal with LWM themes.",
    )
    parser.add_argument(
        "--theme",
        choices=tuple(THEMES),
        help="Select the initial application theme.",
    )
    parser.add_argument(
        "--working-directory",
        "-d",
        metavar="PATH",
        help="Open the first terminal in PATH.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{APP_NAME} {VERSION}",
    )
    return parser


def _resolve_working_directory(value: str | None) -> str | None:
    if not value:
        return None
    candidate = os.path.abspath(os.path.expanduser(value))
    try:
        resolved = os.path.realpath(candidate, strict=True)
    except OSError as error:
        raise ValueError(
            f"working directory is unavailable: {candidate}: {error}"
        ) from error
    if not os.path.isdir(resolved):
        raise ValueError(f"working directory is not a directory: {resolved}")
    return resolved


def main(argv: Sequence[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    options = parser.parse_args(arguments)
    try:
        working_directory = _resolve_working_directory(options.working_directory)
    except ValueError as error:
        parser.error(str(error))

    # GTK remains optional for --help and --version. Importing the GUI only
    # after parsing also makes missing distribution dependencies easy to report.
    try:
        from .application import run_application
    except (ImportError, ValueError) as error:
        print(
            f"{COMMAND_NAME}: GTK4/VTE bindings are unavailable. "
            "Install the dependencies listed in README.md.\n"
            f"Details: {error}",
            file=sys.stderr,
        )
        return 2

    return run_application(
        initial_theme=options.theme,
        initial_working_directory=working_directory,
    )
