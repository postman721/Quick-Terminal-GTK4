"""Build the two shared native Gio menu models."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from .gtk_runtime import Gio
from .themes import THEMES


def build_application_menu() -> Gio.Menu:
    """Return the header-bar application menu."""

    menu = Gio.Menu()

    file_section = Gio.Menu()
    file_section.append("New Tab", "app.new-tab")
    file_section.append("Close Tab", "app.close-tab")
    menu.append_section(None, file_section)

    edit_section = Gio.Menu()
    edit_section.append("Copy", "app.copy")
    edit_section.append("Paste", "app.paste")
    edit_section.append("Select All", "app.select-all")
    menu.append_section(None, edit_section)

    theme_menu = Gio.Menu()
    for theme in THEMES.values():
        theme_menu.append(theme.display_name, f"app.theme::{theme.key}")
    menu.append_submenu("Theme", theme_menu)

    help_section = Gio.Menu()
    help_section.append("About Quick Terminal", "app.about")
    help_section.append("Quit", "app.quit")
    menu.append_section(None, help_section)
    return menu


def build_terminal_menu() -> Gio.Menu:
    """Return the VTE context menu shared by all terminal tabs."""

    menu = Gio.Menu()

    edit_section = Gio.Menu()
    edit_section.append("Copy", "app.copy")
    edit_section.append("Paste", "app.paste")
    edit_section.append("Select All", "app.select-all")
    menu.append_section(None, edit_section)

    tab_section = Gio.Menu()
    tab_section.append("New Tab", "app.new-tab")
    tab_section.append("Close Tab", "app.close-tab")
    menu.append_section(None, tab_section)
    return menu
