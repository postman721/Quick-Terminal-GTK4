"""Quick Terminal application identity and release metadata."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import os
import sys

# The supported launchers also use ``python -B``. Keeping this guard in the
# package protects module execution and embedded imports as well.
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True

APP_ID = "net.techtimejourney.QuickTerminal"
APP_NAME = "Quick Terminal"
COMMAND_NAME = "terminal"
VERSION = "2.5.0"
AUTHOR = "JJ Posti"
PROJECT_WEBSITE = "https://www.techtimejourney.net"
LICENSE_SPDX = "GPL-2.0-or-later"

__all__ = [
    "APP_ID",
    "APP_NAME",
    "AUTHOR",
    "COMMAND_NAME",
    "LICENSE_SPDX",
    "PROJECT_WEBSITE",
    "VERSION",
]
