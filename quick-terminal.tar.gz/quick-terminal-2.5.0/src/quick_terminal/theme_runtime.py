"""Apply one bounded GTK stylesheet and one cached VTE colour palette."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from .gtk_runtime import Gdk, Gtk, Vte
from .themes import ThemeDefinition, clear_css_cache

_COLOUR_THEME: ThemeDefinition | None = None
_COLOUR_VALUES: tuple[object, ...] | None = None


def _rgba(value: str) -> Gdk.RGBA:
    colour = Gdk.RGBA()
    if not colour.parse(value):
        raise ValueError(f"invalid colour value: {value}")
    return colour


def _terminal_colours(theme: ThemeDefinition) -> tuple[object, ...]:
    """Parse and retain only the currently selected terminal palette."""

    global _COLOUR_THEME, _COLOUR_VALUES
    if _COLOUR_THEME is theme and _COLOUR_VALUES is not None:
        return _COLOUR_VALUES

    colours = (
        _rgba(theme.foreground),
        _rgba(theme.background),
        _rgba(theme.cursor),
        _rgba(theme.cursor_foreground),
        _rgba(theme.selection_background),
        _rgba(theme.selection_foreground),
        tuple(_rgba(value) for value in theme.palette),
    )
    _COLOUR_THEME = theme
    _COLOUR_VALUES = colours
    return colours


def apply_terminal_theme(terminal: Vte.Terminal, theme: ThemeDefinition) -> None:
    """Apply foreground, background, cursor, selection, and ANSI colours."""

    (
        foreground,
        background,
        cursor,
        cursor_foreground,
        selection_background,
        selection_foreground,
        palette,
    ) = _terminal_colours(theme)
    terminal.set_colors(foreground, background, palette)
    terminal.set_color_cursor(cursor)
    terminal.set_color_cursor_foreground(cursor_foreground)
    terminal.set_color_highlight(selection_background)
    terminal.set_color_highlight_foreground(selection_foreground)


class GtkThemeController:
    """Keep exactly one application CSS provider installed per display."""

    __slots__ = ("_display", "_provider", "_theme_key")

    def __init__(self) -> None:
        self._display: Gdk.Display | None = None
        self._provider: Gtk.CssProvider | None = None
        self._theme_key: str | None = None

    def apply(self, theme: ThemeDefinition) -> bool:
        display = Gdk.Display.get_default()
        if display is None:
            return False
        if self._provider is not None and self._theme_key == theme.key:
            return True

        provider = Gtk.CssProvider()
        provider.load_from_data(theme.load_css().encode("utf-8"))
        self.close()
        Gtk.StyleContext.add_provider_for_display(
            display,
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        self._display = display
        self._provider = provider
        self._theme_key = theme.key
        return True

    def close(self) -> None:
        """Remove the installed provider and release GTK wrapper references."""

        if self._display is not None and self._provider is not None:
            try:
                Gtk.StyleContext.remove_provider_for_display(
                    self._display,
                    self._provider,
                )
            except (RuntimeError, TypeError, ValueError):
                pass
        self._display = None
        self._provider = None
        self._theme_key = None


def clear_theme_caches() -> None:
    """Release the current colour set and stylesheet on shutdown."""

    global _COLOUR_THEME, _COLOUR_VALUES
    _COLOUR_THEME = None
    _COLOUR_VALUES = None
    clear_css_cache()
