"""Gtk.Application lifecycle, actions, menus, and persisted theme selection."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import sys
from collections.abc import Callable

from . import APP_ID, COMMAND_NAME
from .config import SettingsStore
from .gtk_runtime import Gio, GLib, Gtk
from .menus import build_application_menu, build_terminal_menu
from .paths import clear_path_caches
from .terminal_widgets import clear_terminal_widget_caches
from .theme_runtime import GtkThemeController, clear_theme_caches
from .themes import THEMES, normalize_theme
from .window import QuickTerminalWindow

ActionCallback = Callable[[Gio.SimpleAction, GLib.Variant | None], None]
_CLEANUP_ERRORS = (AttributeError, GLib.Error, RuntimeError, TypeError, ValueError)


class QuickTerminalApplication(Gtk.Application):
    """Own global actions and coordinate the application's single window."""

    def __init__(
        self,
        initial_theme: str | None = None,
        initial_working_directory: str | None = None,
    ) -> None:
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.NON_UNIQUE,
        )
        self.settings_store = SettingsStore()
        stored_theme = self.settings_store.load_theme()
        self._theme_key = normalize_theme(initial_theme or stored_theme)
        self._initial_working_directory = initial_working_directory
        self._theme_controller = GtkThemeController()
        # Store only action names and signal IDs. Gtk.Application already owns
        # the action objects, so duplicate Python references are unnecessary.
        self._action_handlers: list[tuple[str, int]] = []
        self.application_menu = build_application_menu()
        self.terminal_menu = build_terminal_menu()
        self._install_actions()

    def _add_action(
        self,
        name: str,
        action: Gio.SimpleAction,
        callback: ActionCallback,
        signal_name: str = "activate",
    ) -> None:
        handler_id = action.connect(signal_name, callback)
        self.add_action(action)
        self._action_handlers.append((name, handler_id))

    def _install_actions(self) -> None:
        for name, callback in (
            ("new-tab", self._action_new_tab),
            ("close-tab", self._action_close_tab),
            ("copy", self._action_copy),
            ("paste", self._action_paste),
            ("select-all", self._action_select_all),
            ("about", self._action_about),
            ("quit", self._action_quit),
        ):
            self._add_action(name, Gio.SimpleAction.new(name, None), callback)

        theme_action = Gio.SimpleAction.new_stateful(
            "theme",
            GLib.VariantType.new("s"),
            GLib.Variant.new_string(self._theme_key),
        )
        self._add_action(
            "theme",
            theme_action,
            self._action_change_theme,
            signal_name="change-state",
        )

        for action_name, accelerators in (
            ("app.new-tab", ["<Primary><Shift>t"]),
            ("app.close-tab", ["<Primary><Shift>w"]),
            ("app.copy", ["<Primary><Shift>c"]),
            ("app.paste", ["<Primary><Shift>v"]),
            ("app.select-all", ["<Primary><Shift>a"]),
            ("app.quit", ["<Primary>q"]),
        ):
            self.set_accels_for_action(action_name, accelerators)

    def do_activate(self) -> None:
        window = self._current_window()
        if window is None:
            theme = THEMES[self._theme_key]
            self._theme_controller.apply(theme)
            window = QuickTerminalWindow(
                self,
                theme,
                self._initial_working_directory,
            )
            # The window copies the initial path into its first session.
            self._initial_working_directory = None
        window.present()

    def _current_window(self) -> QuickTerminalWindow | None:
        active = self.get_active_window()
        if isinstance(active, QuickTerminalWindow):
            return active
        for window in self.get_windows():
            if isinstance(window, QuickTerminalWindow):
                return window
        return None

    def apply_theme(self, key: str, *, persist: bool) -> None:
        """Apply one normalized theme to GTK, VTE, and optional settings."""

        normalized = normalize_theme(key)
        changed = normalized != self._theme_key
        if changed:
            theme = THEMES[normalized]
            self._theme_controller.apply(theme)
            self._theme_key = normalized
            for window in self.get_windows():
                if isinstance(window, QuickTerminalWindow):
                    window.apply_theme(theme)
        if persist and changed:
            try:
                self.settings_store.save_theme(normalized)
            except OSError as error:
                print(
                    f"{COMMAND_NAME}: could not save settings: {error}",
                    file=sys.stderr,
                )

    def do_shutdown(self) -> None:
        """Disconnect cycles and release all bounded process caches."""

        for name, handler_id in self._action_handlers:
            action = self.lookup_action(name)
            if action is not None:
                try:
                    action.disconnect(handler_id)
                except _CLEANUP_ERRORS:
                    pass
            try:
                self.remove_action(name)
            except _CLEANUP_ERRORS:
                pass
        self._action_handlers.clear()
        self._theme_controller.close()
        clear_terminal_widget_caches()
        clear_theme_caches()
        clear_path_caches()

        # GTK owns these objects while the application is active. Releasing the
        # Python wrappers here shortens shutdown lifetime and breaks any wrapper
        # cycles left by a backend implementation.
        self.application_menu = None
        self.terminal_menu = None
        self.settings_store = None
        self._initial_working_directory = None
        Gtk.Application.do_shutdown(self)

    def _action_new_tab(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.new_tab()

    def _action_close_tab(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.request_close_current_tab()

    def _action_copy(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.copy_selection()

    def _action_paste(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.paste_clipboard()

    def _action_select_all(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.select_all()

    def _action_about(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.show_about()

    def _action_quit(
        self,
        _action: Gio.SimpleAction,
        _parameter: GLib.Variant | None,
    ) -> None:
        window = self._current_window()
        if window is not None:
            window.close()
        else:
            self.quit()

    def _action_change_theme(
        self,
        action: Gio.SimpleAction,
        value: GLib.Variant,
    ) -> None:
        normalized = normalize_theme(value.get_string())
        action.set_state(GLib.Variant.new_string(normalized))
        self.apply_theme(normalized, persist=True)


def run_application(
    *,
    initial_theme: str | None = None,
    initial_working_directory: str | None = None,
) -> int:
    """Create and run GTK after dependency-free CLI parsing succeeds."""

    application = QuickTerminalApplication(
        initial_theme=initial_theme,
        initial_working_directory=initial_working_directory,
    )
    return int(application.run([COMMAND_NAME]))
