"""Small GTK4 dialogs with explicit asynchronous callback ownership."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from collections.abc import Callable

from . import APP_ID, APP_NAME, AUTHOR, PROJECT_WEBSITE, VERSION
from .gtk_runtime import Gio, GLib, Gtk

MAX_DIALOG_MESSAGE_CHARS = 256
MAX_DIALOG_DETAIL_CHARS = 4_096


def _bounded(value: str, limit: int) -> str:
    """Keep native dialog strings bounded even when an exception is unusual."""

    return value if len(value) <= limit else f"{value[: limit - 1]}…"


def confirm(
    parent: Gtk.Window,
    message: str,
    detail: str,
    on_confirm: Callable[[], None],
    on_finished: Callable[[], None],
    *,
    cancellable: Gio.Cancellable | None = None,
) -> Gio.Cancellable:
    """Show a cancellable, non-blocking destructive-action confirmation.

    Long-lived callers create and store the cancellable before entering this
    function. The callback cells are cleared as soon as GTK completes so a
    finished dialog cannot retain a window or terminal session.
    """

    dialog = Gtk.AlertDialog()
    dialog.set_modal(True)
    dialog.set_message(_bounded(message, MAX_DIALOG_MESSAGE_CHARS))
    dialog.set_detail(_bounded(detail, MAX_DIALOG_DETAIL_CHARS))
    dialog.set_buttons(["Cancel", "Close"])
    dialog.set_cancel_button(0)
    dialog.set_default_button(0)

    operation = cancellable if cancellable is not None else Gio.Cancellable()
    confirm_callback: Callable[[], None] | None = on_confirm
    finished_callback: Callable[[], None] | None = on_finished

    def complete(
        source: Gtk.AlertDialog,
        result: Gio.AsyncResult,
        _user_data: object | None,
    ) -> None:
        nonlocal confirm_callback, finished_callback
        try:
            try:
                choice = source.choose_finish(result)
            except (GLib.Error, RuntimeError, TypeError, ValueError):
                choice = 0
            callback = confirm_callback
            if choice == 1 and callback is not None:
                callback()
        finally:
            callback = finished_callback
            confirm_callback = None
            finished_callback = None
            if callback is not None:
                callback()

    try:
        dialog.choose(parent, operation, complete, None)
    except Exception:
        confirm_callback = None
        finished_callback = None
        try:
            operation.cancel()
        except (GLib.Error, RuntimeError, TypeError, ValueError):
            pass
        raise
    return operation


def show_error(parent: Gtk.Window, message: str, detail: str) -> None:
    """Display a bounded modal error without blocking the GTK event loop."""

    dialog = Gtk.AlertDialog()
    dialog.set_modal(True)
    dialog.set_message(_bounded(message, MAX_DIALOG_MESSAGE_CHARS))
    dialog.set_detail(_bounded(detail, MAX_DIALOG_DETAIL_CHARS))
    dialog.show(parent)


def show_about(parent: Gtk.Window) -> None:
    """Display the project's author, website, and GPL-2.0-or-later license."""

    dialog = Gtk.AboutDialog()
    dialog.set_transient_for(parent)
    dialog.set_destroy_with_parent(True)
    dialog.set_modal(True)
    dialog.set_program_name(APP_NAME)
    dialog.set_version(VERSION)
    dialog.set_logo_icon_name(APP_ID)
    dialog.set_copyright(f"Copyright © 2017–2026 {AUTHOR}")
    dialog.set_comments(
        "A lightweight GTK4 terminal emulator with VTE tabs, drag and drop, "
        "and LWM Graphite, LWM Dark, and LWM Blue themes."
    )
    dialog.set_website(PROJECT_WEBSITE)
    dialog.set_website_label("techtimejourney.net")
    dialog.set_authors([f"{AUTHOR} <techtimejourney.net>"])
    # Gtk.License.GPL_2_0 is GTK's explicit "version 2.0 or later" value.
    dialog.set_license_type(Gtk.License.GPL_2_0)
    dialog.present()
