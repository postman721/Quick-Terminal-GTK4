"""GTK4 window and signal-safe terminal-tab lifecycle."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from . import APP_ID, APP_NAME
from . import dialogs
from .gtk_runtime import Gio, GLib, Gtk, Pango, Vte
from .paths import bounded_display_text, safe_working_directory
from .sessions import SessionRegistry, TerminalSession, cancel_operation, cancel_source
from .terminal_widgets import (
    copy_selection,
    create_tab_header,
    create_terminal,
    create_terminal_page,
    current_terminal_directory,
    spawn_shell,
)
from .theme_runtime import apply_terminal_theme
from .themes import ThemeDefinition

MAX_TERMINAL_TITLE_CHARS = 160
MAX_DIRECTORY_LABEL_CHARS = 320
_CLEANUP_ERRORS = (AttributeError, GLib.Error, RuntimeError, TypeError, ValueError)


class QuickTerminalWindow(Gtk.ApplicationWindow):
    """Main window with movable, independently owned terminal tabs."""

    def __init__(
        self,
        application: "QuickTerminalApplication",
        theme: ThemeDefinition,
        initial_working_directory: str | None = None,
    ) -> None:
        super().__init__(application=application)
        self.set_title(APP_NAME)
        self.set_icon_name(APP_ID)
        self.set_default_size(980, 640)
        self.set_size_request(560, 360)
        self.add_css_class("quick-terminal")

        self._theme = theme
        self._sessions = SessionRegistry()
        self._next_session_token = 1
        self._tab_open_source_id = 0
        self._tab_open_session_token = 0
        self._close_source_id = 0
        self._close_prompt_cancellable: Gio.Cancellable | None = None
        self._force_close = False
        self._close_prompt_open = False
        self._initial_working_directory = safe_working_directory(
            initial_working_directory
        )

        self._subtitle_label = Gtk.Label(label=theme.display_name)
        self._subtitle_label.add_css_class("app-subtitle")
        self._subtitle_label.set_ellipsize(Pango.EllipsizeMode.END)
        self._subtitle_label.set_max_width_chars(54)

        self._build_headerbar()
        self._build_notebook()
        self._close_request_handler_id = self.connect(
            "close-request",
            self._on_close_request,
        )
        self.new_tab(working_directory=self._initial_working_directory)
        # The first session now owns the fallback path; the window does not need
        # a duplicate reference for the rest of its lifetime.
        self._initial_working_directory = None

    @property
    def application_object(self) -> "QuickTerminalApplication":
        application = self.get_application()
        if application is None:
            raise RuntimeError("Quick Terminal window has no Gtk.Application")
        return application

    def _build_headerbar(self) -> None:
        header = Gtk.HeaderBar()
        header.add_css_class("terminal-headerbar")

        title_label = Gtk.Label(label=APP_NAME)
        title_label.add_css_class("app-title")
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        title_box.set_valign(Gtk.Align.CENTER)
        title_box.append(title_label)
        title_box.append(self._subtitle_label)
        header.set_title_widget(title_box)

        self._new_tab_button = Gtk.Button.new_from_icon_name("list-add-symbolic")
        self._new_tab_button.set_tooltip_text("New tab (Ctrl+Shift+T)")
        self._new_tab_button.add_css_class("header-action")
        self._new_tab_handler_id = self._new_tab_button.connect(
            "clicked", self._on_new_tab_button_clicked
        )
        header.pack_start(self._new_tab_button)

        menu_button = Gtk.MenuButton()
        menu_button.set_icon_name("open-menu-symbolic")
        menu_button.set_tooltip_text("Quick Terminal menu")
        menu_button.add_css_class("header-action")
        menu_button.set_menu_model(self.application_object.application_menu)
        header.pack_end(menu_button)
        self.set_titlebar(header)

    def _build_notebook(self) -> None:
        """Create the only content widget; no single-child wrapper box is needed."""

        self.notebook = Gtk.Notebook()
        self.notebook.set_hexpand(True)
        self.notebook.set_vexpand(True)
        self.notebook.set_scrollable(True)
        self.notebook.set_show_border(False)
        self._switch_page_handler_id = self.notebook.connect(
            "switch-page", self._on_switch_page
        )
        self.set_child(self.notebook)

    def _allocate_session_token(self) -> int:
        token = self._next_session_token
        self._next_session_token += 1
        return token

    def current_session(self) -> TerminalSession | None:
        """Return the notebook's selected session, when one exists."""

        page_number = self.notebook.get_current_page()
        if page_number < 0:
            return None
        return self._sessions.for_page(self.notebook.get_nth_page(page_number))

    def new_tab(self, working_directory: str | None = None) -> None:
        """Create, register, display, and asynchronously start one terminal."""

        directory = safe_working_directory(
            working_directory or self._current_terminal_directory()
        )
        terminal = create_terminal(
            context_menu=self.application_object.terminal_menu,
            theme=self._theme,
        )
        page = create_terminal_page(terminal)
        tab_box, title_label, close_button = create_tab_header()
        token = self._allocate_session_token()
        tab_click_gesture = Gtk.GestureClick.new()
        tab_click_gesture.set_button(1)
        tab_click_handler_id = tab_click_gesture.connect(
            "pressed",
            self._on_tab_click_pressed,
            token,
        )
        title_label.add_controller(tab_click_gesture)
        session = TerminalSession(
            token=token,
            page=page,
            terminal=terminal,
            tab_label=title_label,
            close_button=close_button,
            working_directory=directory,
            tab_click_gesture=tab_click_gesture,
            tab_click_handler_id=tab_click_handler_id,
        )

        # Tokens are passed directly through VTE signals. This removes the need
        # for a second terminal-widget lookup entry per tab.
        session.child_exited_handler_id = terminal.connect(
            "child-exited", self._on_terminal_child_exited, token
        )
        session.title_changed_handler_id = terminal.connect(
            "window-title-changed", self._on_terminal_title_changed, token
        )
        session.close_handler_id = close_button.connect(
            "clicked", self._on_tab_close_button_clicked, token
        )
        self._sessions.add(session)

        page_number = self.notebook.append_page(page, tab_box)
        self.notebook.set_tab_reorderable(page, True)
        self.notebook.set_current_page(page_number)
        try:
            spawn_shell(session, self._on_spawn_finished)
        except (GLib.Error, OSError, RuntimeError, TypeError, ValueError) as error:
            dialogs.show_error(self, "Could not start the shell", str(error))
            self._queue_session_removal(session)
            return
        self._update_title_for_session(session)
        self._schedule_focus(session)

    def _on_spawn_finished(
        self,
        terminal: Vte.Terminal | None,
        _pid: int,
        error: GLib.Error | None,
        session_token: int,
    ) -> None:
        session = self._sessions.for_token(session_token)
        if session is None:
            return
        session.finish_spawn()
        if terminal is None or error is not None:
            dialogs.show_error(
                self,
                "Could not start the shell",
                str(error or "VTE did not return a terminal"),
            )
            self._queue_session_removal(session)

    def _current_terminal_directory(self) -> str | None:
        session = self.current_session()
        if session is None:
            return self._initial_working_directory
        return current_terminal_directory(session.terminal) or session.working_directory

    def copy_selection(self) -> None:
        session = self.current_session()
        if session is not None:
            copy_selection(session.terminal)

    def paste_clipboard(self) -> None:
        session = self.current_session()
        if session is not None:
            session.terminal.paste_clipboard()
            session.terminal.grab_focus()

    def select_all(self) -> None:
        session = self.current_session()
        if session is not None:
            session.terminal.select_all()
            session.terminal.grab_focus()

    def request_close_current_tab(self) -> None:
        session = self.current_session()
        if session is not None:
            self.request_close_session(session)

    def request_close_session(self, session: TerminalSession) -> None:
        """Confirm one close request and suppress duplicate prompts."""

        if session not in self._sessions or session.closing:
            return
        session.closing = True
        token = session.token

        def confirmed() -> None:
            current = self._sessions.for_token(token)
            if current is not None:
                self._queue_session_removal(current)

        operation: Gio.Cancellable

        def finished() -> None:
            current = self._sessions.for_token(token)
            if current is None:
                return
            if current.close_prompt_cancellable is operation:
                current.close_prompt_cancellable = None
            if not current.removal_source_id:
                current.closing = False

        operation = Gio.Cancellable()
        session.close_prompt_cancellable = operation
        try:
            dialogs.confirm(
                self,
                "Close this terminal tab?",
                "The shell and any command running in this tab will be stopped.",
                confirmed,
                finished,
                cancellable=operation,
            )
        except (GLib.Error, RuntimeError, TypeError, ValueError) as error:
            if session.close_prompt_cancellable is operation:
                session.close_prompt_cancellable = None
            session.closing = False
            cancel_operation(operation)
            dialogs.show_error(self, "Could not show confirmation", str(error))

    def _queue_session_removal(self, session: TerminalSession) -> None:
        """Remove a tab only after the current GTK/VTE signal returns."""

        if session not in self._sessions:
            return
        session.closing = True
        if session.removal_source_id:
            return
        session.removal_source_id = GLib.idle_add(
            self._remove_session_once,
            session.token,
        )

    def _remove_session_once(self, session_token: int) -> bool:
        session = self._sessions.for_token(session_token)
        if session is not None:
            session.removal_source_id = 0
            self._remove_session(session)
        return GLib.SOURCE_REMOVE

    def _remove_session(self, session: TerminalSession) -> None:
        cancel_source(session.removal_source_id)
        session.removal_source_id = 0
        if not self._sessions.remove(session):
            return

        page = session.page
        page_number = self.notebook.page_num(page)
        session.dispose()
        if page_number >= 0:
            self.notebook.remove_page(page_number)

        if not self._sessions:
            self._finalize_close()
            return

        current = self.current_session()
        if current is not None:
            self._update_title_for_session(current)

    def _cancel_pending_removals(self) -> None:
        for session in self._sessions:
            source_id = session.removal_source_id
            session.removal_source_id = 0
            cancel_source(source_id)

    def _dispose_all_sessions(self) -> None:
        """Release sessions one at a time without a temporary reference copy."""

        self._cancel_pending_removals()
        while self._sessions:
            session = self._sessions.pop()
            if session is None:
                break
            page = session.page
            page_number = self.notebook.page_num(page)
            session.dispose()
            if page_number >= 0:
                self.notebook.remove_page(page_number)

        # Defensive cleanup for a page left unregistered by construction failure.
        while self.notebook.get_n_pages() > 0:
            self.notebook.remove_page(-1)

    def _on_terminal_child_exited(
        self,
        _terminal: Vte.Terminal,
        _status: int,
        session_token: int,
    ) -> None:
        session = self._sessions.for_token(session_token)
        if session is not None:
            self._queue_session_removal(session)

    @staticmethod
    def _terminal_title(terminal: Vte.Terminal) -> str:
        try:
            value = terminal.get_window_title()
        except (GLib.Error, RuntimeError, TypeError, ValueError):
            value = None
        return bounded_display_text(value, "Terminal", MAX_TERMINAL_TITLE_CHARS)

    def _on_terminal_title_changed(
        self,
        terminal: Vte.Terminal,
        session_token: int,
    ) -> None:
        session = self._sessions.for_token(session_token)
        if session is None:
            return
        title = self._terminal_title(terminal)
        session.tab_label.set_text(title)
        if session is self.current_session():
            self._update_title_for_session(session)

    def _update_title_for_session(self, session: TerminalSession) -> None:
        title = self._terminal_title(session.terminal)
        directory = (
            current_terminal_directory(session.terminal) or session.working_directory
        )
        display_directory = bounded_display_text(
            directory,
            "/",
            MAX_DIRECTORY_LABEL_CHARS,
        )
        self.set_title(f"{title} — {APP_NAME}")
        self._subtitle_label.set_text(
            f"{display_directory}  ·  {self._theme.display_name}"
        )
        self._subtitle_label.set_tooltip_text(display_directory)

    def _schedule_focus(self, session: TerminalSession) -> None:
        if session.closing or session.disposed:
            return
        cancel_source(session.focus_source_id)
        session.focus_source_id = GLib.idle_add(
            self._focus_session_once,
            session.token,
        )

    def _focus_session_once(self, session_token: int) -> bool:
        session = self._sessions.for_token(session_token)
        if session is not None:
            session.focus_source_id = 0
            if not session.closing and session is self.current_session():
                session.terminal.grab_focus()
        return GLib.SOURCE_REMOVE

    def _on_switch_page(
        self,
        _notebook: Gtk.Notebook,
        page: Gtk.Widget,
        _page_number: int,
    ) -> None:
        session = self._sessions.for_page(page)
        if session is not None:
            self._update_title_for_session(session)
            self._schedule_focus(session)

    def _on_new_tab_button_clicked(self, _button: Gtk.Button) -> None:
        self.new_tab()

    def _on_tab_click_pressed(
        self,
        _gesture: Gtk.GestureClick,
        n_press: int,
        _x: float,
        _y: float,
        session_token: int,
    ) -> None:
        """Queue one new tab after a primary-button double-click finishes."""

        if n_press != 2 or self._force_close:
            return
        session = self._sessions.for_token(session_token)
        if session is None or session.closing or session.disposed:
            return
        self._queue_new_tab_from_session(session)

    def _queue_new_tab_from_session(self, session: TerminalSession) -> None:
        """Defer tab creation so notebook click handling finishes first."""

        if (
            self._force_close
            or self._tab_open_source_id
            or session not in self._sessions
            or session.closing
            or session.disposed
        ):
            return
        self._tab_open_session_token = session.token
        self._tab_open_source_id = GLib.idle_add(self._open_new_tab_once)

    def _open_new_tab_once(self) -> bool:
        session_token = self._tab_open_session_token
        self._tab_open_source_id = 0
        self._tab_open_session_token = 0
        if self._force_close:
            return GLib.SOURCE_REMOVE

        session = self._sessions.for_token(session_token)
        if session is None or session.closing or session.disposed:
            return GLib.SOURCE_REMOVE
        directory = (
            current_terminal_directory(session.terminal)
            or session.working_directory
        )
        self.new_tab(working_directory=directory)
        return GLib.SOURCE_REMOVE

    def _on_tab_close_button_clicked(
        self,
        _button: Gtk.Button,
        session_token: int,
    ) -> None:
        session = self._sessions.for_token(session_token)
        if session is not None:
            self.request_close_session(session)

    def _release_window_signals(self) -> None:
        if not (
            self._new_tab_handler_id
            or self._switch_page_handler_id
            or self._close_request_handler_id
        ):
            return
        for instance, handler_id in (
            (self._new_tab_button, self._new_tab_handler_id),
            (self.notebook, self._switch_page_handler_id),
            (self, self._close_request_handler_id),
        ):
            try:
                instance.disconnect(handler_id)
            except _CLEANUP_ERRORS:
                pass
        self._new_tab_handler_id = 0
        self._switch_page_handler_id = 0
        self._close_request_handler_id = 0

    def _finalize_close(self) -> None:
        if self._force_close:
            return
        self._force_close = True
        cancel_source(self._tab_open_source_id)
        self._tab_open_source_id = 0
        self._tab_open_session_token = 0
        cancel_source(self._close_source_id)
        self._close_source_id = 0
        prompt = self._close_prompt_cancellable
        self._close_prompt_cancellable = None
        cancel_operation(prompt)
        self._close_prompt_open = False
        self._release_window_signals()
        self._dispose_all_sessions()
        self.close()

    def _queue_window_close(self) -> None:
        if self._force_close or self._close_source_id:
            return
        self._close_source_id = GLib.idle_add(self._finalize_close_once)

    def _finalize_close_once(self) -> bool:
        self._close_source_id = 0
        self._finalize_close()
        return GLib.SOURCE_REMOVE

    def _on_close_request(self, _window: Gtk.Window) -> bool:
        if self._force_close or not self._sessions:
            return False
        if self._close_prompt_open:
            return True
        self._close_prompt_open = True

        def confirmed() -> None:
            self._queue_window_close()

        operation = Gio.Cancellable()

        def finished() -> None:
            if self._close_prompt_cancellable is operation:
                self._close_prompt_cancellable = None
            if not self._close_source_id and not self._force_close:
                self._close_prompt_open = False

        self._close_prompt_cancellable = operation
        try:
            dialogs.confirm(
                self,
                "Close Quick Terminal?",
                f"Closing the window will stop {len(self._sessions)} terminal session(s).",
                confirmed,
                finished,
                cancellable=operation,
            )
        except (GLib.Error, RuntimeError, TypeError, ValueError) as error:
            if self._close_prompt_cancellable is operation:
                self._close_prompt_cancellable = None
            self._close_prompt_open = False
            cancel_operation(operation)
            dialogs.show_error(self, "Could not show confirmation", str(error))
        return True

    def show_about(self) -> None:
        dialogs.show_about(self)

    def apply_theme(self, theme: ThemeDefinition) -> None:
        """Refresh the window and every existing VTE terminal palette."""

        self._theme = theme
        for session in self._sessions:
            apply_terminal_theme(session.terminal, theme)
        current = self.current_session()
        if current is not None:
            self._update_title_for_session(current)
        else:
            self._subtitle_label.set_text(theme.display_name)
