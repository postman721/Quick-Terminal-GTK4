"""Bounded and atomic storage for Quick Terminal's selected theme."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import json
import os
from pathlib import Path

from .themes import DEFAULT_THEME, normalize_theme

MAX_SETTINGS_BYTES = 4 * 1024


class SettingsStore:
    """Load and save one small JSON file below ``XDG_CONFIG_HOME``."""

    __slots__ = ("path",)

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or self.default_path()

    @staticmethod
    def default_path() -> Path:
        configured = os.environ.get("XDG_CONFIG_HOME")
        root = Path(configured).expanduser() if configured else Path.home() / ".config"
        return root / "quick-terminal" / "settings.json"

    def load_theme(self) -> str:
        """Return the stored theme while rejecting malformed or oversized data."""

        try:
            with self.path.open("rb") as stream:
                raw = stream.read(MAX_SETTINGS_BYTES + 1)
            if len(raw) > MAX_SETTINGS_BYTES:
                return DEFAULT_THEME
            payload = json.loads(raw)
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError, ValueError):
            return DEFAULT_THEME
        if not isinstance(payload, dict):
            return DEFAULT_THEME
        value = payload.get("theme")
        return normalize_theme(value if isinstance(value, str) else None)

    def save_theme(self, theme: str) -> None:
        """Replace the settings file atomically and keep it private."""

        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.tmp-{os.getpid()}")
        payload = json.dumps(
            {"theme": normalize_theme(theme)},
            separators=(",", ":"),
        ) + "\n"
        try:
            with temporary.open("w", encoding="utf-8") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                temporary.chmod(0o600)
            except OSError:
                pass
            os.replace(temporary, self.path)
        finally:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
