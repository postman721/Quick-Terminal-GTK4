"""Load the exact GTK4 and VTE introspection namespaces used by the GUI."""

# SPDX-FileCopyrightText: 2017-2026 JJ Posti <https://www.techtimejourney.net>
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import gi

# Version requirements must precede every gi.repository import. Keeping them in
# one module prevents PyGI warnings and namespace drift between UI modules.
gi.require_version("Gdk", "4.0")
gi.require_version("Gtk", "4.0")
gi.require_version("Pango", "1.0")
gi.require_version("Vte", "3.91")
from gi.repository import Gdk, Gio, GLib, Gtk, Pango, Vte  # noqa: E402

__all__ = ["Gdk", "Gio", "GLib", "Gtk", "Pango", "Vte"]
