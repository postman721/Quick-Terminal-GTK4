from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import tomllib
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from quick_terminal import (  # noqa: E402
    APP_ID,
    AUTHOR,
    COMMAND_NAME,
    LICENSE_SPDX,
    PROJECT_WEBSITE,
    VERSION,
)
from quick_terminal.config import MAX_SETTINGS_BYTES, SettingsStore  # noqa: E402
import quick_terminal.paths as path_helpers  # noqa: E402
from quick_terminal.paths import (  # noqa: E402
    MAX_DROP_BYTES,
    MAX_DROP_ITEM_CHARS,
    MAX_DROP_ITEMS,
    _process_shell,
    bounded_display_text,
    clear_path_caches,
    preferred_shell,
    safe_working_directory,
    shell_quoted_drop_payload,
)
from quick_terminal.themes import DEFAULT_THEME, THEMES, normalize_theme  # noqa: E402


class ThemeTests(unittest.TestCase):
    def test_bundled_lwm_themes(self) -> None:
        self.assertEqual(
            set(THEMES),
            {"lwm-graphite", "lwm-dark", "lwm-blue"},
        )
        self.assertEqual(DEFAULT_THEME, "lwm-graphite")
        self.assertEqual(THEMES["lwm-graphite"].background, "#17191b")
        self.assertEqual(THEMES["lwm-dark"].background, "#000000")
        self.assertEqual(THEMES["lwm-blue"].foreground, "#ffffff")
        self.assertEqual(THEMES["lwm-blue"].cursor, "#ffffff")
        for theme in THEMES.values():
            self.assertEqual(len(theme.palette), 16)

    def test_blue_css_uses_white_text(self) -> None:
        css = THEMES["lwm-blue"].load_css()
        self.assertIn("@define-color lwm_foreground #ffffff", css)
        self.assertIn("@define-color lwm_muted #ffffff", css)
        self.assertIn("window.quick-terminal", css)
        self.assertIn("popover modelbutton", css)
        self.assertIn("dialog label", css)
        self.assertNotIn("QMainWindow", css)
        self.assertNotIn("QToolButton", css)

    def test_all_css_is_gtk4_and_cached(self) -> None:
        for theme in THEMES.values():
            first = theme.load_css()
            second = theme.load_css()
            self.assertIs(first, second)
            self.assertIn("notebook > header", first)
            self.assertIn("popover > contents", first)
            self.assertIn(".terminal-surface", first)

    def test_theme_aliases(self) -> None:
        self.assertEqual(normalize_theme("graphite"), "lwm-graphite")
        self.assertEqual(normalize_theme("LWM DARK"), "lwm-dark")
        self.assertEqual(normalize_theme("blue"), "lwm-blue")
        self.assertEqual(normalize_theme("LWM BLUE"), "lwm-blue")
        self.assertEqual(normalize_theme("unknown"), DEFAULT_THEME)


class SettingsAndPathTests(unittest.TestCase):
    def test_settings_round_trip_and_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "settings.json"
            store = SettingsStore(path)
            self.assertEqual(store.load_theme(), DEFAULT_THEME)
            store.save_theme("lwm-blue")
            self.assertEqual(store.load_theme(), "lwm-blue")
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            path.write_text("not-json", encoding="utf-8")
            self.assertEqual(store.load_theme(), DEFAULT_THEME)
            path.write_bytes(b"x" * (MAX_SETTINGS_BYTES + 1))
            self.assertEqual(store.load_theme(), DEFAULT_THEME)

    def test_process_shell_cache_is_explicitly_releasable(self) -> None:
        clear_path_caches()
        self.assertIsNone(path_helpers._CACHED_SHELL)
        self.assertEqual(_process_shell(), "/bin/bash")
        self.assertEqual(path_helpers._CACHED_SHELL, "/bin/bash")
        clear_path_caches()
        self.assertIsNone(path_helpers._CACHED_SHELL)

    def test_shell_and_directory_resolution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            environment = {"HOME": temporary, "SHELL": "/not/executable"}
            self.assertEqual(
                safe_working_directory("/missing", environment),
                str(Path(temporary).resolve()),
            )
            self.assertEqual(preferred_shell(environment), "/bin/bash")

    def test_bounded_display_and_drop_payloads(self) -> None:
        title = bounded_display_text("x" * 1_000, "Terminal", 64)
        self.assertEqual(len(title), 64)
        self.assertTrue(title.endswith("…"))
        self.assertEqual(bounded_display_text("\n\t", "Terminal", 64), "Terminal")

        payload = shell_quoted_drop_payload(["/tmp/a file", "/tmp/b"])
        self.assertEqual(payload, b"'/tmp/a file' /tmp/b ")
        many = shell_quoted_drop_payload(f"item-{index}" for index in range(500))
        self.assertLessEqual(len(many), MAX_DROP_BYTES)
        self.assertEqual(len(many.decode().split()), MAX_DROP_ITEMS)
        oversized = "x" * (MAX_DROP_ITEM_CHARS + 1)
        self.assertEqual(shell_quoted_drop_payload([oversized, "/tmp/ok"]), b"/tmp/ok ")


class CommandLineTests(unittest.TestCase):
    def _run(self, *arguments: str) -> subprocess.CompletedProcess[str]:
        environment = {
            **os.environ,
            "PYTHONPATH": "",
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        return subprocess.run(
            [sys.executable, "-B", str(ROOT / "bin/terminal"), *arguments],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=environment,
        )

    def test_version_does_not_require_gi(self) -> None:
        self.assertEqual(COMMAND_NAME, "terminal")
        completed = self._run("--version")
        self.assertEqual(completed.stdout.strip(), f"Quick Terminal {VERSION}")

    def test_help_lists_all_themes_without_gi(self) -> None:
        completed = self._run("--help")
        for theme in ("lwm-graphite", "lwm-dark", "lwm-blue"):
            self.assertIn(theme, completed.stdout)


class SourceLayoutTests(unittest.TestCase):
    def test_modular_pure_python_layout(self) -> None:
        package = SRC / "quick_terminal"
        expected = {
            "__init__.py",
            "__main__.py",
            "application.py",
            "cli.py",
            "config.py",
            "dialogs.py",
            "gtk_runtime.py",
            "menus.py",
            "paths.py",
            "sessions.py",
            "terminal_widgets.py",
            "theme_runtime.py",
            "themes.py",
            "window.py",
        }
        actual = {path.name for path in package.glob("*.py")}
        self.assertEqual(actual, expected)
        for obsolete in (
            "app.py",
            "models.py",
            "system.py",
            "terminal_view.py",
            "widgets.py",
        ):
            self.assertFalse((package / obsolete).exists())
        for obsolete_root in ("terminal.py", "MIGRATION.md", "bashrc"):
            self.assertFalse((ROOT / obsolete_root).exists())
        for obsolete_launcher in (
            "bin/quick-terminal",
            "debian/quick-terminal.wrapper",
            "man/quick-terminal.1",
        ):
            self.assertFalse((ROOT / obsolete_launcher).exists())
        self.assertTrue((ROOT / "bin/terminal").is_file())
        self.assertTrue((ROOT / "man/terminal.1").is_file())

        native_suffixes = {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".pro"}
        native_files = [
            path
            for path in ROOT.rglob("*")
            if path.is_file() and path.suffix.lower() in native_suffixes
        ]
        self.assertEqual(native_files, [])
        for name in ("CMakeLists.txt", "meson.build"):
            self.assertFalse((ROOT / name).exists())

    def test_gtk4_port_uses_modern_apis(self) -> None:
        runtime = (SRC / "quick_terminal/gtk_runtime.py").read_text(encoding="utf-8")
        application = (SRC / "quick_terminal/application.py").read_text(
            encoding="utf-8"
        )
        window = (SRC / "quick_terminal/window.py").read_text(encoding="utf-8")
        terminal = (SRC / "quick_terminal/terminal_widgets.py").read_text(
            encoding="utf-8"
        )
        paths = (SRC / "quick_terminal/paths.py").read_text(encoding="utf-8")
        dialogs = (SRC / "quick_terminal/dialogs.py").read_text(encoding="utf-8")
        self.assertIn('gi.require_version("Gdk", "4.0")', runtime)
        self.assertIn('gi.require_version("Gtk", "4.0")', runtime)
        self.assertIn('gi.require_version("Pango", "1.0")', runtime)
        self.assertIn('gi.require_version("Vte", "3.91")', runtime)
        import_line = runtime.index("from gi.repository import")
        for namespace in ("Gdk", "Gtk", "Pango", "Vte"):
            self.assertLess(
                runtime.index(f'gi.require_version("{namespace}",'),
                import_line,
            )
        self.assertIn("class QuickTerminalApplication(Gtk.Application)", application)
        self.assertIn("class QuickTerminalWindow(Gtk.ApplicationWindow)", window)
        self.assertIn('"close-request"', window)
        self.assertIn("_close_request_handler_id", window)
        self.assertNotIn("Gtk.GestureClick", terminal)
        self.assertIn("set_allow_hyperlink(False)", terminal)
        self.assertIn("clear_terminal_widget_caches", terminal)
        self.assertIn("Gtk.DropTarget.new", terminal)
        self.assertIn("shlex.quote", paths)
        self.assertIn("child_setup_data required by the PyGObject binding", terminal)
        self.assertIn("SCROLLBACK_LINES = 1_024", terminal)
        self.assertIn("Vte.CursorBlinkMode.SYSTEM", terminal)
        self.assertIn("shell_quoted_drop_payload", terminal)
        self.assertIn("set_enable_sixel(False)", terminal)
        self.assertNotIn("hasattr(", terminal)
        combined = runtime + application + window + terminal
        for old_api in ("Gtk.main()", "Gdk.Screen", "Gtk.MenuItem", "shell=True"):
            self.assertNotIn(old_api, combined)
        self.assertNotIn("from dataclasses import", combined)
        self.assertNotIn("from typing import", combined)
        self.assertNotIn("lru_cache", combined)
        self.assertNotIn("popup_enable", window)
        self.assertNotIn("set_group_name", window)

        sessions = (SRC / "quick_terminal/sessions.py").read_text(encoding="utf-8")
        for cleanup in (
            "spawn_cancellable",
            "GLib.source_remove",
            "disconnect",
            "normal ownership order",
        ):
            self.assertIn(cleanup, sessions)
        for unsafe_teardown in (
            "remove_controller",
            "set_scrollback_lines",
            '"reset"',
            "set_context_menu_model",
            "set_pty",
            "set_child",
        ):
            self.assertNotIn(unsafe_teardown, sessions)
        self.assertIn("session.token", terminal)
        self.assertNotIn("callback,\n        session,", terminal)
        self.assertIn("_queue_session_removal", window)
        self.assertIn("GLib.idle_add", window)
        self.assertIn("removal_source_id", window)
        self.assertNotIn("_removal_sources", window)
        self.assertIn("_dispose_all_sessions", window)
        self.assertIn("_release_window_signals", window)
        self.assertIn("clear_theme_caches", application)
        self.assertIn("clear_path_caches", application)
        self.assertIn("_action_handlers", application)
        self.assertIn("remove_action", application)
        self.assertIn("close_prompt_cancellable", sessions)
        self.assertNotIn("drop_target:", sessions)
        self.assertIn("_page_tokens", sessions)
        self.assertNotIn("_widget_tokens", sessions)
        self.assertNotIn("for_terminal", sessions)
        self.assertIn("def pop(", sessions)
        self.assertIn("_compact_if_sparse", sessions)
        self.assertNotIn("def drain(", sessions)
        self.assertIn("bounded_display_text", window)
        self.assertIn("cancellable=operation", window)
        self.assertIn("Gtk.GestureClick.new()", window)
        self.assertIn("n_press != 2", window)
        self.assertIn("_tab_open_source_id", window)
        self.assertIn("tab_click_gesture", sessions)
        self.assertIn("confirm_callback = None", dialogs)
        self.assertIn("Gtk.License.GPL_2_0", dialogs)
        self.assertNotIn("GPL_2_0 or later", dialogs)

    def test_readme_lists_current_distribution_dependencies(self) -> None:
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        for value in (
            "pure Python application",
            "Debian 13 (Trixie)",
            "python3-gi",
            "gir1.2-gtk-4.0",
            "gir1.2-vte-3.91",
            "Arch Linux",
            "python-gobject",
            "vte4",
            "Fedora",
            "python3-gobject",
            "vte291-gtk4",
            "/usr/lib/quick-terminal",
            "/bin/bash",
            "1,024-line",
            "/usr/bin/terminal",
        ):
            self.assertIn(value, readme)
        self.assertIn("signal-safe tab removal", readme.lower())
        self.assertIn("JJ Posti", readme)
        self.assertIn("GPL-2.0-or-later", readme)

    def test_debian_packaging_is_private_and_bytecode_free(self) -> None:
        control = (ROOT / "debian/control").read_text(encoding="utf-8")
        rules = (ROOT / "debian/rules").read_text(encoding="utf-8")
        launcher = (ROOT / "debian/terminal.wrapper").read_text(encoding="utf-8")
        for value in (
            "debhelper-compat (= 13)",
            "python3-gi",
            "gir1.2-gtk-4.0",
            "gir1.2-vte-3.91",
            "bash",
            "Architecture: all",
        ):
            self.assertIn(value, control)
        self.assertNotIn("dh-python", control)
        self.assertNotIn("dh_python3", rules)
        self.assertIn("/usr/lib/quick-terminal", rules)
        self.assertIn("usr/bin/terminal", rules)
        self.assertNotIn("usr/bin/quick-terminal", rules)
        self.assertNotIn("dist-packages", rules)
        self.assertIn("sys.dont_write_bytecode = True", launcher)
        self.assertIn('sys.path.insert(0, "/usr/lib/quick-terminal")', launcher)
        for path in (
            ROOT / "debian/rules",
            ROOT / "debian/terminal.wrapper",
            ROOT / "debian/quick-terminal.postinst",
            ROOT / "debian/quick-terminal.postrm",
            ROOT / "debian/tests/smoke",
        ):
            self.assertTrue(os.access(path, os.X_OK), path)

    def test_metadata_and_versions_match(self) -> None:
        desktop = (ROOT / "data" / f"{APP_ID}.desktop").read_text(encoding="utf-8")
        self.assertIn("Exec=terminal", desktop)
        self.assertNotIn("Exec=quick-terminal", desktop)
        self.assertIn(f"Icon={APP_ID}", desktop)

        tree = ET.parse(ROOT / "data" / f"{APP_ID}.metainfo.xml")
        self.assertEqual(tree.getroot().findtext("id"), APP_ID)
        releases = tree.getroot().find("releases")
        self.assertIsNotNone(releases)
        self.assertEqual(releases[0].attrib["version"], VERSION)

        metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
        self.assertEqual(metadata["project"]["version"], VERSION)
        self.assertEqual(metadata["project"]["authors"][0]["name"], AUTHOR)
        self.assertEqual(PROJECT_WEBSITE, "https://www.techtimejourney.net")
        self.assertEqual(LICENSE_SPDX, "GPL-2.0-or-later")
        self.assertIn(
            "License :: OSI Approved :: GNU General Public License v2 or later (GPLv2+)",
            metadata["project"]["classifiers"],
        )
        self.assertNotIn("scripts", metadata["project"])
        self.assertEqual(
            metadata["tool"]["setuptools"]["script-files"],
            ["bin/terminal"],
        )
        self.assertIn(
            VERSION, (ROOT / "man/terminal.1").read_text(encoding="utf-8")
        )
        self.assertTrue(
            (ROOT / "debian/changelog")
            .read_text(encoding="utf-8")
            .startswith(f"quick-terminal ({VERSION}-1)")
        )
        self.assertEqual(
            tree.getroot().findtext("project_license"),
            "GPL-2.0-or-later",
        )
        copying = (ROOT / "COPYING").read_text(encoding="utf-8")
        self.assertIn("GNU GENERAL PUBLIC LICENSE", copying)
        self.assertIn("Version 2, June 1991", copying)
        copyright_text = (ROOT / "Copyright").read_text(encoding="utf-8")
        self.assertIn("JJ Posti", copyright_text)
        self.assertIn("any later version", copyright_text)

    def test_repository_hygiene_and_bytecode_policy(self) -> None:
        gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")
        attributes = (ROOT / ".gitattributes").read_text(encoding="utf-8")
        for marker in (
            "__pycache__",
            "*.pyc",
            "*.pyo",
            "*$py.class",
            ".*_cache",
            ".pyright",
            ".pytype",
            ".venv",
            "build",
            "dist",
            "*.egg-info",
            "*.dist-info",
            "*.whl",
            "debian/tmp",
            "debian/files",
            "*.deb",
            "*.dsc",
        ):
            self.assertIn(marker, gitignore)
            self.assertIn(marker, attributes)

        generated = [
            path
            for path in ROOT.rglob("*")
            if path.name == "__pycache__" or path.suffix in {".pyc", ".pyo"}
        ]
        self.assertEqual(generated, [])

    def test_supported_launchers_disable_project_bytecode(self) -> None:
        for relative in (
            "bin/terminal",
            "debian/terminal.wrapper",
            "src/quick_terminal/__init__.py",
            "src/quick_terminal/__main__.py",
        ):
            source = (ROOT / relative).read_text(encoding="utf-8")
            self.assertIn("dont_write_bytecode", source, relative)
        makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
        self.assertIn("PYTHONDONTWRITEBYTECODE=1", makefile)
        self.assertIn("bytecode-check", makefile)
        self.assertIn("tools/gui_smoke.py", makefile)


if __name__ == "__main__":
    unittest.main()
