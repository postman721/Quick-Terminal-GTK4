"""Regression tests for VTE spawn argument placement and cancellation."""

from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class _Flags:
    DEFAULT = object()


class _Cancellable:
    def __init__(self) -> None:
        self.cancelled = False

    def cancel(self) -> None:
        self.cancelled = True


class _FakeTerminal:
    def __init__(self) -> None:
        self.arguments: tuple[object, ...] | None = None

    def spawn_async(self, *arguments: object) -> None:
        self.arguments = arguments


class _FailingTerminal:
    def spawn_async(self, *_arguments: object) -> None:
        raise RuntimeError("spawn failed")


class SpawnLayoutTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = types.ModuleType("quick_terminal.gtk_runtime")
        runtime.Gdk = types.SimpleNamespace(FileList=object, DragAction=_Flags)
        runtime.Gio = types.SimpleNamespace(Cancellable=_Cancellable)
        runtime.GLib = types.SimpleNamespace(SpawnFlags=_Flags, Error=Exception)
        runtime.Gtk = types.SimpleNamespace()
        runtime.Pango = types.SimpleNamespace()
        runtime.Vte = types.SimpleNamespace(PtyFlags=_Flags, Format=_Flags)
        sys.modules["quick_terminal.gtk_runtime"] = runtime

        for name in (
            "quick_terminal.sessions",
            "quick_terminal.theme_runtime",
            "quick_terminal.terminal_widgets",
        ):
            sys.modules.pop(name, None)

        self.widgets = importlib.import_module("quick_terminal.terminal_widgets")
        self.widgets.preferred_shell = lambda: "/bin/test-shell"

    def tearDown(self) -> None:
        for name in (
            "quick_terminal.terminal_widgets",
            "quick_terminal.theme_runtime",
            "quick_terminal.sessions",
            "quick_terminal.gtk_runtime",
        ):
            sys.modules.pop(name, None)

    def test_spawn_async_keeps_callback_and_cancellable_in_correct_slots(self) -> None:
        terminal = _FakeTerminal()
        session = types.SimpleNamespace(
            terminal=terminal,
            working_directory="/tmp/example",
            token=73,
            spawn_cancellable=None,
            disposed=False,
        )
        callback = object()

        self.widgets.spawn_shell(session, callback)

        self.assertIsNotNone(terminal.arguments)
        self.assertEqual(len(terminal.arguments), 11)
        self.assertEqual(terminal.arguments[1], "/tmp/example")
        self.assertEqual(terminal.arguments[2], ["/bin/test-shell"])
        self.assertIsNone(terminal.arguments[3])  # envv
        self.assertIsNone(terminal.arguments[5])  # child_setup
        self.assertIsNone(terminal.arguments[6])  # child_setup_data
        self.assertEqual(terminal.arguments[7], -1)  # timeout
        self.assertIs(terminal.arguments[8], session.spawn_cancellable)
        self.assertIs(terminal.arguments[9], callback)
        self.assertEqual(terminal.arguments[10], 73)
        self.assertFalse(session.spawn_cancellable.cancelled)

    def test_failed_spawn_cancels_and_releases_the_cancellable(self) -> None:
        session = types.SimpleNamespace(
            terminal=_FailingTerminal(),
            working_directory="/tmp/example",
            token=9,
            spawn_cancellable=None,
            disposed=False,
        )

        with self.assertRaisesRegex(RuntimeError, "spawn failed"):
            self.widgets.spawn_shell(session, object())

        self.assertIsNone(session.spawn_cancellable)

    def test_disposed_session_is_rejected_before_allocating_a_cancellable(self) -> None:
        session = types.SimpleNamespace(
            terminal=_FakeTerminal(),
            working_directory="",
            token=10,
            disposed=True,
            spawn_cancellable=None,
        )

        with self.assertRaisesRegex(RuntimeError, "disposed terminal session"):
            self.widgets.spawn_shell(session, object())

        self.assertIsNone(session.spawn_cancellable)


if __name__ == "__main__":
    unittest.main()
