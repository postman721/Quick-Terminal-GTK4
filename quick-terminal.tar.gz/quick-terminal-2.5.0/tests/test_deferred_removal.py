"""Dependency-free tests for GTK-idle tab and window removal."""

from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class _IdleLoop:
    SOURCE_REMOVE = False
    Error = Exception

    def __init__(self) -> None:
        self.calls: list[tuple[int, object, tuple[object, ...]]] = []
        self.removed_source_ids: list[int] = []
        self.next_source_id = 100

    def idle_add(self, callback, *arguments):
        self.next_source_id += 1
        self.calls.append((self.next_source_id, callback, arguments))
        return self.next_source_id

    def source_remove(self, source_id: int) -> None:
        self.removed_source_ids.append(source_id)


class _Registry:
    def __init__(self, session: object) -> None:
        self.session = session

    def __contains__(self, candidate: object) -> bool:
        return candidate is self.session

    def for_token(self, token: int):
        return self.session if token == self.session.token else None


class DeferredRemovalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.glib = _IdleLoop()
        runtime = types.ModuleType("quick_terminal.gtk_runtime")
        runtime.GLib = self.glib
        runtime.Gtk = types.SimpleNamespace(
            ApplicationWindow=object,
            Window=object,
            Notebook=object,
            Widget=object,
            Button=object,
            GestureClick=object,
            Label=object,
            ScrolledWindow=object,
            DropTarget=object,
        )
        runtime.Pango = types.SimpleNamespace()
        runtime.Vte = types.SimpleNamespace(Terminal=object)
        runtime.Gio = types.SimpleNamespace(Cancellable=object)
        sys.modules["quick_terminal.gtk_runtime"] = runtime

        dialogs = types.ModuleType("quick_terminal.dialogs")
        dialogs.confirm = lambda *_args, **_kwargs: None
        dialogs.show_error = lambda *_args, **_kwargs: None
        dialogs.show_about = lambda *_args, **_kwargs: None
        sys.modules["quick_terminal.dialogs"] = dialogs

        widgets = types.ModuleType("quick_terminal.terminal_widgets")
        for name in (
            "copy_selection",
            "create_tab_header",
            "create_terminal",
            "create_terminal_page",
            "current_terminal_directory",
            "spawn_shell",
        ):
            setattr(widgets, name, lambda *_args, **_kwargs: None)
        sys.modules["quick_terminal.terminal_widgets"] = widgets

        runtime_theme = types.ModuleType("quick_terminal.theme_runtime")
        runtime_theme.apply_terminal_theme = lambda *_args, **_kwargs: None
        sys.modules["quick_terminal.theme_runtime"] = runtime_theme

        for name in ("quick_terminal.sessions", "quick_terminal.window"):
            sys.modules.pop(name, None)
        self.window_module = importlib.import_module("quick_terminal.window")

    def tearDown(self) -> None:
        for name in (
            "quick_terminal.window",
            "quick_terminal.sessions",
            "quick_terminal.theme_runtime",
            "quick_terminal.terminal_widgets",
            "quick_terminal.dialogs",
            "quick_terminal.gtk_runtime",
        ):
            sys.modules.pop(name, None)

    def test_tab_removal_waits_for_the_gtk_idle_loop(self) -> None:
        instance = object.__new__(self.window_module.QuickTerminalWindow)
        session = types.SimpleNamespace(token=7, closing=False, removal_source_id=0)
        instance._sessions = _Registry(session)
        removed: list[object] = []
        instance._remove_session = removed.append

        instance._queue_session_removal(session)
        instance._queue_session_removal(session)

        self.assertTrue(session.closing)
        self.assertEqual(removed, [])
        self.assertEqual(len(self.glib.calls), 1)
        source_id, callback, arguments = self.glib.calls[0]
        self.assertEqual(session.removal_source_id, source_id)

        self.assertFalse(callback(*arguments))
        self.assertEqual(removed, [session])
        self.assertEqual(session.removal_source_id, 0)

    def test_tab_double_click_opens_after_the_current_gtk_event(self) -> None:
        instance = object.__new__(self.window_module.QuickTerminalWindow)
        session = types.SimpleNamespace(
            token=17,
            terminal=object(),
            working_directory="/fallback",
            closing=False,
            disposed=False,
        )
        instance._sessions = _Registry(session)
        instance._force_close = False
        instance._tab_open_source_id = 0
        instance._tab_open_session_token = 0
        opened_directories: list[str | None] = []
        instance.new_tab = lambda working_directory=None: opened_directories.append(
            working_directory
        )
        self.window_module.current_terminal_directory = lambda _terminal: "/live"

        instance._on_tab_click_pressed(None, 1, 0.0, 0.0, 17)
        instance._on_tab_click_pressed(None, 2, 0.0, 0.0, 17)
        instance._on_tab_click_pressed(None, 2, 0.0, 0.0, 17)
        instance._on_tab_click_pressed(None, 3, 0.0, 0.0, 17)

        self.assertEqual(opened_directories, [])
        self.assertEqual(len(self.glib.calls), 1)
        source_id, callback, arguments = self.glib.calls[0]
        self.assertEqual(instance._tab_open_source_id, source_id)
        self.assertEqual(instance._tab_open_session_token, 17)

        self.assertFalse(callback(*arguments))
        self.assertEqual(opened_directories, ["/live"])
        self.assertEqual(instance._tab_open_source_id, 0)
        self.assertEqual(instance._tab_open_session_token, 0)

    def test_tab_double_click_ignores_closing_or_missing_sessions(self) -> None:
        instance = object.__new__(self.window_module.QuickTerminalWindow)
        session = types.SimpleNamespace(
            token=23,
            terminal=object(),
            working_directory="/fallback",
            closing=True,
            disposed=False,
        )
        instance._sessions = _Registry(session)
        instance._force_close = False
        instance._tab_open_source_id = 0
        instance._tab_open_session_token = 0

        instance._on_tab_click_pressed(None, 2, 0.0, 0.0, 23)
        instance._on_tab_click_pressed(None, 2, 0.0, 0.0, 999)

        self.assertEqual(self.glib.calls, [])
        self.assertEqual(instance._tab_open_source_id, 0)
        self.assertEqual(instance._tab_open_session_token, 0)

    def test_window_close_cancels_a_pending_double_click_open(self) -> None:
        instance = object.__new__(self.window_module.QuickTerminalWindow)
        instance._force_close = False
        instance._tab_open_source_id = 171
        instance._tab_open_session_token = 17
        instance._close_source_id = 0
        instance._close_prompt_cancellable = None
        instance._close_prompt_open = True
        instance._release_window_signals = lambda: None
        instance._dispose_all_sessions = lambda: None
        closed: list[bool] = []
        instance.close = lambda: closed.append(True)

        instance._finalize_close()

        self.assertTrue(instance._force_close)
        self.assertEqual(self.glib.removed_source_ids, [171])
        self.assertEqual(instance._tab_open_source_id, 0)
        self.assertEqual(instance._tab_open_session_token, 0)
        self.assertFalse(instance._close_prompt_open)
        self.assertEqual(closed, [True])

    def test_window_close_waits_for_the_gtk_idle_loop(self) -> None:
        instance = object.__new__(self.window_module.QuickTerminalWindow)
        instance._force_close = False
        instance._close_source_id = 0
        finalized: list[bool] = []
        instance._finalize_close = lambda: finalized.append(True)

        instance._queue_window_close()
        instance._queue_window_close()

        self.assertEqual(finalized, [])
        self.assertEqual(len(self.glib.calls), 1)
        source_id, callback, arguments = self.glib.calls[0]
        self.assertEqual(instance._close_source_id, source_id)

        self.assertFalse(callback(*arguments))
        self.assertEqual(finalized, [True])
        self.assertEqual(instance._close_source_id, 0)


if __name__ == "__main__":
    unittest.main()
