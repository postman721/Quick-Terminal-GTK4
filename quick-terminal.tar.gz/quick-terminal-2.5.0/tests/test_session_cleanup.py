"""Dependency-free tests for safe terminal-session cleanup."""

from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class _SignalSource:
    def __init__(self) -> None:
        self.disconnected: list[int] = []

    def disconnect(self, handler_id: int) -> None:
        self.disconnected.append(handler_id)


class _Cancellable:
    def __init__(self) -> None:
        self.cancelled = False

    def cancel(self) -> None:
        self.cancelled = True


class SessionCleanupTests(unittest.TestCase):
    def setUp(self) -> None:
        self.removed_sources: list[int] = []
        runtime = types.ModuleType("quick_terminal.gtk_runtime")
        runtime.Gio = types.SimpleNamespace(Cancellable=_Cancellable)
        runtime.GLib = types.SimpleNamespace(
            Error=Exception,
            source_remove=self.removed_sources.append,
        )
        runtime.Gtk = types.SimpleNamespace(
            ScrolledWindow=object,
            Label=object,
            Button=object,
            GestureClick=object,
            DropTarget=object,
            Widget=object,
        )
        runtime.Vte = types.SimpleNamespace(Terminal=object)
        sys.modules["quick_terminal.gtk_runtime"] = runtime
        sys.modules.pop("quick_terminal.sessions", None)
        self.sessions = importlib.import_module("quick_terminal.sessions")

    def tearDown(self) -> None:
        sys.modules.pop("quick_terminal.sessions", None)
        sys.modules.pop("quick_terminal.gtk_runtime", None)

    def _session(self, token: int = 1):
        terminal = _SignalSource()
        close_button = _SignalSource()
        tab_click_gesture = _SignalSource()
        spawn_cancellable = _Cancellable()
        close_prompt_cancellable = _Cancellable()
        session = self.sessions.TerminalSession(
            token=token,
            page=object(),
            terminal=terminal,
            tab_label=object(),
            close_button=close_button,
            working_directory="/tmp",
            tab_click_gesture=tab_click_gesture,
            spawn_cancellable=spawn_cancellable,
            close_prompt_cancellable=close_prompt_cancellable,
            child_exited_handler_id=11,
            title_changed_handler_id=12,
            close_handler_id=21,
            tab_click_handler_id=31,
            focus_source_id=51,
            removal_source_id=52,
        )
        return (
            session,
            terminal,
            close_button,
            tab_click_gesture,
            spawn_cancellable,
            close_prompt_cancellable,
        )

    def test_dispose_cancels_callbacks_without_mutating_live_vte_state(self) -> None:
        (
            session,
            terminal,
            close_button,
            tab_click_gesture,
            spawn_cancellable,
            close_prompt_cancellable,
        ) = self._session()

        session.dispose()
        session.dispose()  # idempotent

        self.assertTrue(session.disposed)
        self.assertTrue(session.closing)
        self.assertTrue(spawn_cancellable.cancelled)
        self.assertTrue(close_prompt_cancellable.cancelled)
        self.assertEqual(self.removed_sources, [51, 52])
        self.assertEqual(terminal.disconnected, [11, 12])
        self.assertEqual(close_button.disconnected, [21])
        self.assertEqual(tab_click_gesture.disconnected, [31])
        self.assertIsNone(session.spawn_cancellable)
        self.assertIsNone(session.close_prompt_cancellable)
        self.assertEqual(session.focus_source_id, 0)
        self.assertEqual(session.removal_source_id, 0)
        self.assertFalse(hasattr(session, "__dict__"))
        self.assertEqual(session.child_exited_handler_id, 0)
        self.assertEqual(session.title_changed_handler_id, 0)
        self.assertEqual(session.close_handler_id, 0)
        self.assertEqual(session.tab_click_handler_id, 0)
        self.assertIsNone(session.page)
        self.assertIsNone(session.terminal)
        self.assertIsNone(session.tab_label)
        self.assertIsNone(session.close_button)
        self.assertIsNone(session.tab_click_gesture)
        self.assertEqual(session.working_directory, "")

    def test_registry_secondary_indexes_store_tokens_not_session_references(self) -> None:
        session, *_resources = self._session(token=7)
        registry = self.sessions.SessionRegistry()
        registry.add(session)

        self.assertIs(registry.for_token(7), session)
        self.assertIs(registry.for_page(session.page), session)
        self.assertEqual(registry._page_tokens, {id(session.page): 7})
        self.assertTrue(registry.remove(session))
        self.assertFalse(registry)

    def test_registry_compacts_after_large_tab_churn(self) -> None:
        registry = self.sessions.SessionRegistry()
        sessions = [self._session(token=index + 1)[0] for index in range(64)]
        for session in sessions:
            registry.add(session)

        original_items = id(registry._items)
        original_pages = id(registry._page_tokens)
        for session in sessions[:-4]:
            self.assertTrue(registry.remove(session))

        self.assertEqual(len(registry), 4)
        self.assertNotEqual(id(registry._items), original_items)
        self.assertNotEqual(id(registry._page_tokens), original_pages)
        self.assertLessEqual(registry._peak_size, 16)
        self.assertEqual(len(registry._page_tokens), 4)

    def test_registry_pop_drains_one_session_without_bulk_copy(self) -> None:
        registry = self.sessions.SessionRegistry()
        sessions = [self._session(token=index + 1)[0] for index in range(64)]
        for session in sessions:
            registry.add(session)

        popped: list[object] = []
        while registry:
            session = registry.pop()
            self.assertIsNotNone(session)
            popped.append(session)

        self.assertEqual(len(popped), 64)
        self.assertFalse(registry)
        self.assertEqual(registry._items, {})
        self.assertEqual(registry._page_tokens, {})
        self.assertIsNone(registry.pop())

    def test_cancel_helpers_ignore_empty_operations(self) -> None:
        self.sessions.cancel_source(0)
        self.sessions.cancel_operation(None)
        self.assertEqual(self.removed_sources, [])


if __name__ == "__main__":
    unittest.main()
