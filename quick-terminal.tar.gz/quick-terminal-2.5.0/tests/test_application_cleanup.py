"""Dependency-free regression tests for application-level resource release."""

from __future__ import annotations

import importlib
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))


class _BaseApplication:
    def __new__(cls, *_args, **_kwargs):
        return object.__new__(cls)

    def __init__(self, *_args, **_kwargs) -> None:
        self.base_shutdown_called = False
        self.removed_actions: list[str] = []
        self.actions: dict[str, object] = {}

    def lookup_action(self, name: str):
        return self.actions.get(name)

    def remove_action(self, name: str) -> None:
        self.removed_actions.append(name)
        self.actions.pop(name, None)

    def do_shutdown(self) -> None:
        self.base_shutdown_called = True


class _Action:
    def __init__(self) -> None:
        self.disconnected: list[int] = []

    def disconnect(self, handler_id: int) -> None:
        self.disconnected.append(handler_id)


class _ThemeController:
    def __init__(self) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True


class ApplicationCleanupTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = types.ModuleType("quick_terminal.gtk_runtime")
        runtime.Gio = types.SimpleNamespace(
            SimpleAction=object,
            ApplicationFlags=types.SimpleNamespace(NON_UNIQUE=object()),
        )
        runtime.GLib = types.SimpleNamespace(Error=RuntimeError, Variant=object)
        runtime.Gtk = types.SimpleNamespace(Application=_BaseApplication)
        sys.modules["quick_terminal.gtk_runtime"] = runtime

        config = types.ModuleType("quick_terminal.config")
        config.SettingsStore = object
        sys.modules["quick_terminal.config"] = config

        menus = types.ModuleType("quick_terminal.menus")
        menus.build_application_menu = lambda: object()
        menus.build_terminal_menu = lambda: object()
        sys.modules["quick_terminal.menus"] = menus

        self.calls: list[str] = []
        paths = types.ModuleType("quick_terminal.paths")
        paths.clear_path_caches = lambda: self.calls.append("paths")
        sys.modules["quick_terminal.paths"] = paths

        widgets = types.ModuleType("quick_terminal.terminal_widgets")
        widgets.clear_terminal_widget_caches = lambda: self.calls.append("terminal")
        sys.modules["quick_terminal.terminal_widgets"] = widgets

        theme_runtime = types.ModuleType("quick_terminal.theme_runtime")
        theme_runtime.GtkThemeController = _ThemeController
        theme_runtime.clear_theme_caches = lambda: self.calls.append("theme")
        sys.modules["quick_terminal.theme_runtime"] = theme_runtime

        themes = types.ModuleType("quick_terminal.themes")
        themes.THEMES = {}
        themes.normalize_theme = lambda value: value
        sys.modules["quick_terminal.themes"] = themes

        window = types.ModuleType("quick_terminal.window")
        window.QuickTerminalWindow = object
        sys.modules["quick_terminal.window"] = window

        sys.modules.pop("quick_terminal.application", None)
        self.application_module = importlib.import_module("quick_terminal.application")

    def tearDown(self) -> None:
        for name in (
            "quick_terminal.application",
            "quick_terminal.window",
            "quick_terminal.themes",
            "quick_terminal.theme_runtime",
            "quick_terminal.terminal_widgets",
            "quick_terminal.paths",
            "quick_terminal.menus",
            "quick_terminal.config",
            "quick_terminal.gtk_runtime",
        ):
            sys.modules.pop(name, None)

    def test_shutdown_disconnects_actions_and_clears_every_bounded_cache(self) -> None:
        application = object.__new__(self.application_module.QuickTerminalApplication)
        _BaseApplication.__init__(application)
        first = _Action()
        second = _Action()
        application.actions = {"new-tab": first, "theme": second}
        application._action_handlers = [
            ("new-tab", 11),
            ("theme", 22),
        ]
        application._theme_controller = _ThemeController()
        application.application_menu = object()
        application.terminal_menu = object()
        application.settings_store = object()
        application._initial_working_directory = "/tmp"

        application.do_shutdown()

        self.assertEqual(first.disconnected, [11])
        self.assertEqual(second.disconnected, [22])
        self.assertEqual(application.removed_actions, ["new-tab", "theme"])
        self.assertEqual(application._action_handlers, [])
        self.assertTrue(application._theme_controller.closed)
        self.assertIsNone(application.application_menu)
        self.assertIsNone(application.terminal_menu)
        self.assertIsNone(application.settings_store)
        self.assertIsNone(application._initial_working_directory)
        self.assertEqual(self.calls, ["terminal", "theme", "paths"])
        self.assertTrue(application.base_shutdown_called)


if __name__ == "__main__":
    unittest.main()
