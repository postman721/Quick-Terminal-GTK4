"""Regression tests for cancellable GTK dialog callback ownership."""

from __future__ import annotations

import gc
import importlib
import sys
import types
import unittest
import weakref
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


class _Cancellable:
    def __init__(self) -> None:
        self.cancelled = False

    def cancel(self) -> None:
        self.cancelled = True


class _AlertDialog:
    last: "_AlertDialog | None" = None

    def __init__(self) -> None:
        type(self).last = self
        self.callback = None
        self.operation = None
        self.choice = 0

    def set_modal(self, _value):
        pass

    def set_message(self, _value):
        pass

    def set_detail(self, _value):
        pass

    def set_buttons(self, _value):
        pass

    def set_cancel_button(self, _value):
        pass

    def set_default_button(self, _value):
        pass

    def choose(self, _parent, operation, callback, _user_data):
        self.operation = operation
        self.callback = callback

    def choose_finish(self, _result):
        return self.choice


class _Owner:
    pass


class DialogCleanupTests(unittest.TestCase):
    def setUp(self) -> None:
        runtime = types.ModuleType("quick_terminal.gtk_runtime")
        runtime.Gio = types.SimpleNamespace(Cancellable=_Cancellable, AsyncResult=object)
        runtime.GLib = types.SimpleNamespace(Error=RuntimeError)
        runtime.Gtk = types.SimpleNamespace(
            AlertDialog=_AlertDialog,
            Window=object,
            AboutDialog=object,
            License=types.SimpleNamespace(GPL_2_0=object()),
        )
        sys.modules["quick_terminal.gtk_runtime"] = runtime
        sys.modules.pop("quick_terminal.dialogs", None)
        self.dialogs = importlib.import_module("quick_terminal.dialogs")

    def tearDown(self) -> None:
        _AlertDialog.last = None
        sys.modules.pop("quick_terminal.dialogs", None)
        sys.modules.pop("quick_terminal.gtk_runtime", None)

    def test_provided_cancellable_is_used_and_callbacks_release_owners(self) -> None:
        owner = _Owner()
        owner_ref = weakref.ref(owner)
        operation = _Cancellable()
        confirmed: list[bool] = []
        finished: list[bool] = []

        def on_confirm(captured=owner):
            confirmed.append(bool(captured))

        def on_finished(captured=owner):
            finished.append(bool(captured))

        returned = self.dialogs.confirm(
            object(),
            "Close?",
            "Details",
            on_confirm,
            on_finished,
            cancellable=operation,
        )
        dialog = _AlertDialog.last
        self.assertIsNotNone(dialog)
        self.assertIs(returned, operation)
        self.assertIs(dialog.operation, operation)

        del owner, on_confirm, on_finished
        gc.collect()
        self.assertIsNotNone(owner_ref())

        dialog.choice = 0
        dialog.callback(dialog, object(), None)
        gc.collect()
        self.assertIsNone(owner_ref())
        self.assertEqual(confirmed, [])
        self.assertEqual(finished, [True])


if __name__ == "__main__":
    unittest.main()
